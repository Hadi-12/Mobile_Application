package it.polito.timebanking

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat

class TimeSlotAdapter(val fragment: Fragment): RecyclerView.Adapter<TimeSlotAdapter.TimeSlotHolder>() {
    class TimeSlotHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val ownerLayout: LinearLayout = itemView.findViewById(R.id.card_actions_property)
        private val notOwnerLayout: LinearLayout = itemView.findViewById(R.id.card_actions_not_property)
        private val title: TextView = itemView.findViewById(R.id.card_title)
        private val location: TextView = itemView.findViewById(R.id.card_location)
        private val date: TextView = itemView.findViewById(R.id.card_date)
        private val time: TextView = itemView.findViewById(R.id.card_time)
        private val favorite: ImageButton = itemView.findViewById(R.id.card_button_favorite)
        private val edit: ImageButton = itemView.findViewById(R.id.card_button_edit)
        private val duration : TextView = itemView.findViewById(R.id.card_duration)
        private val assignedTV : TextView = itemView.findViewById(R.id.assigned_timeslot_tv)
        private val serviceTypeTV : TextView = itemView.findViewById(R.id.service_type_timeslot_item_tv)
        private val delete: ImageButton = itemView.findViewById(R.id.card_button_delete)
        private val goToUser: ImageButton = itemView.findViewById(R.id.card_button_gotouser)

        fun bind(timeSlot: TimeSlot, detailsAction: (v: View)->Unit, editAction: (v: View)->Unit, deleteAction:(v: View)->Unit, context: Context, showServiceTypeLabel: Boolean, favoriteAction: (v: View)->Unit, goToUserAction: (v: View)->Unit) {
            if (FirebaseAuth.getInstance().currentUser!!.uid == timeSlot.userID) {
                notOwnerLayout.visibility = GONE
                ownerLayout.visibility = VISIBLE
                edit.setOnClickListener(editAction)
                delete.setOnClickListener(deleteAction)
            }
            else {
                if(timeSlot.interestedUsers.contains(FirebaseAuth.getInstance().currentUser!!.uid)) {
                    favorite.setImageResource(R.drawable.ic_baseline_favorite_primary_24)
                } else {
                    favorite.setImageResource(R.drawable.ic_baseline_favorite_border_primary_24)
                }
                ownerLayout.visibility = GONE
                notOwnerLayout.visibility = VISIBLE
                favorite.setOnClickListener(favoriteAction)
                goToUser.setOnClickListener(goToUserAction)
            }
            title.text = timeSlot.title
            location.text = timeSlot.location
            date.text = SimpleDateFormat.getDateInstance().format(timeSlot.date.toDate())
            time.text = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT)
                .format(timeSlot.date.toDate())
            duration.text = timeSlot.duration.representAsString()
            if (showServiceTypeLabel) {
                serviceTypeTV.text = timeSlot.serviceType
                serviceTypeTV.visibility = VISIBLE
            } else {
                serviceTypeTV.visibility = GONE
            }
            itemView.setOnClickListener {
                if (itemView.scrollX != 0) {
                    itemView.scrollTo(0, 0)
                }
                else {
                    detailsAction(it)
                }
            }
            if (timeSlot.assignedTo != null) {
                if (timeSlot.userID != FirebaseAuth.getInstance().currentUser!!.uid) {
                    if (timeSlot.assignedTo == FirebaseAuth.getInstance().currentUser!!.uid) {
                        assignedTV.text = context.getString(R.string.you_were_assigned)
                        assignedTV.setCompoundDrawablesWithIntrinsicBounds(
                            ContextCompat.getDrawable(
                                context,
                                R.drawable.ic_baseline_check_circle_24
                            ), null, null, null
                        )
                    } else {
                        assignedTV.text = context.getString(R.string.assigned_to_another)
                        assignedTV.setCompoundDrawablesWithIntrinsicBounds(
                            ContextCompat.getDrawable(
                                context,
                                R.drawable.ic_baseline_cancel_32
                            ), null, null, null
                        )
                    }
                } else {
                    assignedTV.text = context.getString(R.string.assigned)
                    assignedTV.setCompoundDrawablesWithIntrinsicBounds(
                        ContextCompat.getDrawable(
                            context,
                            R.drawable.ic_baseline_check_circle_24
                        ), null, null, null
                    )
                }
                assignedTV.visibility = VISIBLE
            } else {
                assignedTV.visibility = GONE
            }
        }
        fun unbind() {
            delete.setOnClickListener(null)
            edit.setOnClickListener(null)
            itemView.setOnClickListener(null)
        }
    }

    private var timeslots = mutableListOf<TimeSlot>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeSlotHolder {
        val item = LayoutInflater.from(parent.context).inflate(R.layout.timeslot_item, parent, false)
        return TimeSlotHolder(item)
    }

    override fun onBindViewHolder(holder: TimeSlotHolder, position: Int) {
        holder.bind(timeslots[position], detailsAction = {
            when (fragment) {
                is TimeSlotListFragment -> fragment.openDetailsFragment(timeslots[position].id!!)
                is FavoritesListFragment -> fragment.openDetailsFragment(timeslots[position].id!!)
                is MyOffersListFragment -> fragment.openDetailsFragment(timeslots[position].id!!)
            }
        }, editAction = {
            if (fragment is TimeSlotListFragment)
                fragment.openEditFragment(timeslots[position].id!!)
            else if (fragment is MyOffersListFragment)
                fragment.openEditFragment(timeslots[position].id!!)
        }, deleteAction = {
            MaterialAlertDialogBuilder(holder.itemView.context)
                .setTitle("Wait!")
                .setMessage("Are you sure you want to delete \"${timeslots[position].title}\"?")
                .setNegativeButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                }
                .setPositiveButton("Yes") { _, _ ->
                    if (fragment is TimeSlotListFragment) {
                        fragment.timeSlotVM.deleteTimeSlot(timeslots[position].id.toString())
                        timeslots.remove(timeslots[position])
                        fragment.timeSlotVM.getOrderedByTitle()
                            .observe(fragment.viewLifecycleOwner) {
                                setTimeSlotList(it)
                            }
                        notifyItemRemoved(position)
                    }

                }.show()
        }, fragment.requireContext(), fragment !is TimeSlotListFragment, favoriteAction =  {
            if (fragment is TimeSlotListFragment) fragment.favoriteAction(timeslots[position])
            if (fragment is FavoritesListFragment) fragment.favoriteAction(timeslots[position])
        }, goToUserAction = {
            if (fragment is TimeSlotListFragment) fragment.goToUserAction(timeslots[position].userID)
        })
    }

    override fun onViewRecycled(holder: TimeSlotHolder) {
        holder.unbind()
    }

    fun setTimeSlotList(list: List<TimeSlot>) {
        val timeslotsDiffCallback = TimeslotsDiffCallback(timeslots, list)
        val timeslotsDiffResult = DiffUtil.calculateDiff(timeslotsDiffCallback)
        timeslots = list.toMutableList()
        timeslotsDiffResult.dispatchUpdatesTo(this)
    }

    override fun getItemCount(): Int = timeslots.size

    fun addFilter(text : String){
        val newData = timeslots.filter{ it.title.contains(text, ignoreCase = true) }
        setTimeSlotList(newData)
    }
}
class TimeslotsDiffCallback(private val oldList: List<TimeSlot>, private val newList: List<TimeSlot>) : DiffUtil.Callback() {
    override fun getOldListSize(): Int = oldList.size

    override fun getNewListSize(): Int = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition].id == newList[newItemPosition].id

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition] == newList[newItemPosition]

}