package it.polito.timebanking

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.MutableLiveData
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat

class TimeSlotDetailsFragment: Fragment(R.layout.timeslot_details_fragment_layout) {
    private lateinit var topAppBar: MaterialToolbar
    private val args: TimeSlotDetailsFragmentArgs by navArgs()
    private val timeSlotVM by viewModels<TimeSlotViewModel> {
        TimeSlotViewModelFactory(requireActivity().application, args.serviceType)
    }
    private val conversationsViewModel by viewModels<ConversationViewModel>()
    private val userVM by viewModels<UserViewModel>()
    private lateinit var titleTextView: TextView
    private lateinit var offeredByLayout: LinearLayout
    private lateinit var userButton: Button
    private lateinit var descriptionTextView: TextView
    private lateinit var serviceTypeTextView: TextView
    private lateinit var dateTextView: TextView
    private lateinit var timeTextView: TextView
    private lateinit var durationTextView: TextView
    private lateinit var locationTextView: TextView
    private var timeslotId: String? = ""
    private var userCredit: Int = 0
    private var timeslotUserID: MutableLiveData<String?> = MutableLiveData()
    private lateinit var timeslotUserName: String
    private lateinit var timeslotTitle: String
    private var isFavorited: MutableLiveData<Boolean> = MutableLiveData<Boolean>()
    private var assignedTo: MutableLiveData<String?> = MutableLiveData<String?>()
    private var timeslotObj: MutableLiveData<TimeSlot?> = MutableLiveData<TimeSlot?>()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        topAppBar = activity?.findViewById(R.id.topAppBar) as MaterialToolbar
        titleTextView = view.findViewById(R.id.title_timeslot_detail_tv)
        userButton = view.findViewById(R.id.user_offering_button)
        offeredByLayout = view.findViewById(R.id.offered_by_layout)
        descriptionTextView = view.findViewById(R.id.description_timeslot_detail_tv)
        serviceTypeTextView = view.findViewById(R.id.service_type_timeslot_detail_tv)
        dateTextView = view.findViewById(R.id.date_timeslot_detail_tv)
        timeTextView = view.findViewById(R.id.time_timeslot_detail_tv)
        durationTextView = view.findViewById(R.id.duration_timeslot_detail_tv)
        locationTextView = view.findViewById(R.id.location_timeslot_detail_tv)
        timeslotId = args.timeslotId
        if (timeslotId != null) {
            val timeSlot = timeSlotVM.getTimeSlot(timeslotId!!)
            timeSlot.observe(this.viewLifecycleOwner) {
                timeslotObj.postValue(it)
                if (it != null) {
                    assignedTo.postValue(it.assignedTo)
                    if (it.interestedUsers.contains(FirebaseAuth.getInstance().currentUser!!.uid)) {
                        isFavorited.postValue(true)
                    }
                    else {
                        isFavorited.postValue(false)
                    }
                    timeslotUserID.postValue(it.userID)
                    timeslotTitle = it.title
                    titleTextView.text = it.title
                    userVM.getUser(it.userID).observe(this.viewLifecycleOwner) { user ->
                        if (user != null) {
                            userCredit = user.credit
                            timeslotUserName = user.fullname
                            userButton.text = user.fullname
                            userButton.setOnClickListener { _ ->
                                findNavController().navigate(TimeSlotDetailsFragmentDirections.actionTimeSlotDetailsFragmentToShowProfileFragment(it.userID))
                            }
                            offeredByLayout.visibility = View.VISIBLE
                        }
                    }
                    descriptionTextView.text = it.description
                    serviceTypeTextView.text = it.serviceType
                    dateTextView.text = SimpleDateFormat.getDateInstance().format(it.date.toDate())
                    timeTextView.text = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).format(it.date.toDate())
                    durationTextView.text = it.duration.representAsString()
                    locationTextView.text = it.location
                }
                else {
                    timeslotUserID.postValue(null)
                    Snackbar.make(requireView(), "ERROR: timeslot doesn't exist", Snackbar.LENGTH_SHORT).show()
                    findNavController().navigateUp()
                }
            }
        }
        else {
            timeslotUserID.postValue(null)
            Snackbar.make(requireView(), "ERROR: timeslot doesn't exist", Snackbar.LENGTH_SHORT).show()
            findNavController().navigateUp()
        }
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        timeslotUserID.observe(this.viewLifecycleOwner) {
            if (it != null && FirebaseAuth.getInstance().currentUser!!.uid == it) {
                menu.clear()
                assignedTo.observe(viewLifecycleOwner) { assigned ->
                    if (assigned == null)
                        inflater.inflate(R.menu.edit_menu, menu)
                }
            } else if(FirebaseAuth.getInstance().currentUser!!.uid != it) {
                menu.clear()
                inflater.inflate(R.menu.timeslot_not_mine_menu, menu)
                assignedTo.observe(viewLifecycleOwner) { assigned ->
                    if (assigned != null && assigned != FirebaseAuth.getInstance().currentUser!!.uid) {
                        menu.removeItem(1)
                    }
                }
                isFavorited.observe(viewLifecycleOwner) { favorited ->
                    if (favorited) {
                        menu.getItem(0).icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_baseline_favorite_32)
                    } else {
                        menu.getItem(0).icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_baseline_favorite_border_32)
                    }
                }
            }
        }
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.edit_menu_item -> {
                findNavController().navigate(TimeSlotDetailsFragmentDirections.actionTimeSlotDetailsFragmentToTimeSlotEditFragment(timeslotId, args.serviceType))
                true
            }
            R.id.message->{
                if(userCredit.minus(timeslotObj.value!!.duration)>0) {
                    conversationsViewModel.getConversationIDFromTimeslotReferredAndUsersOrCreate(
                        timeslotId!!,
                        timeslotUserID.value.toString(),
                        FirebaseAuth.getInstance().currentUser!!.uid
                    ).observe(viewLifecycleOwner) {
                        if (it != null) {
                            if (it == -1) {
                                MaterialAlertDialogBuilder(requireContext())
                                    .setTitle("Contact timeslot owner")
                                    .setMessage("Do you want to get in contact with ${timeslotUserName}? Timeslot will be added to your favorites")
                                    .setPositiveButton("Yes") { _, _ ->
                                        conversationsViewModel.createConversation(
                                            timeslotId!!,
                                            timeslotUserID.value.toString(),
                                            FirebaseAuth.getInstance().currentUser!!.uid,
                                            timeslotTitle
                                        ).observe(viewLifecycleOwner) { id ->
                                            if (id != null) {
                                                if (timeslotObj.value != null) {
                                                    if (!timeslotObj.value!!.interestedUsers.contains(
                                                            FirebaseAuth.getInstance().currentUser!!.uid
                                                        )
                                                    ) {
                                                        timeSlotVM.switchInterestedUserToTimeslot(
                                                            timeslotObj.value!!.id!!,
                                                            FirebaseAuth.getInstance().currentUser!!.uid
                                                        )
                                                    }
                                                }
                                                findNavController().navigate(
                                                    TimeSlotDetailsFragmentDirections.actionTimeSlotDetailsFragmentToChatFragment(
                                                        id
                                                    )
                                                )
                                            } else {
                                                Snackbar.make(
                                                    requireView(),
                                                    "Couldn't create conversation in database",
                                                    Snackbar.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                    }
                                    .setNegativeButton("No") { dialog, _ ->
                                        dialog.dismiss()
                                    }
                                    .show()
                            } else {
                                findNavController().navigate(
                                    TimeSlotDetailsFragmentDirections.actionTimeSlotDetailsFragmentToChatFragment(
                                        it as String
                                    )
                                )
                            }
                        } else {
                            Snackbar.make(
                                requireView(),
                                "Conversation not found in database",
                                Snackbar.LENGTH_SHORT
                            ).show()
                        }
                    }
                }else{
                    Snackbar.make(
                        requireView(),
                        "Not enough credits",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
                true
            }
            R.id.favorite -> {
                if (isFavorited.value == true) {
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Remove from favorites?")
                        .setMessage("Do you want to remove this offer from your favorites?")
                        .setPositiveButton("Yes") { _, _ ->
                            timeSlotVM.switchInterestedUserToTimeslot(
                                timeslotId!!,
                                FirebaseAuth.getInstance().currentUser!!.uid
                            ).observe(viewLifecycleOwner) { result ->
                                if (!result) {
                                    Snackbar.make(
                                        requireView(),
                                        "There was an error removing this timeslot to your favorites. Try again",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        }
                        .setNegativeButton("No") { dialog, _ ->
                            dialog.dismiss()
                        }
                        .show()
                } else {
                    MaterialAlertDialogBuilder(requireContext())
                        .setTitle("Add to favorites?")
                        .setMessage("Do you want to add this offer to your favorites?")
                        .setPositiveButton("Yes") { _, _ ->
                            timeSlotVM.switchInterestedUserToTimeslot(
                                timeslotId!!,
                                FirebaseAuth.getInstance().currentUser!!.uid
                            ).observe(viewLifecycleOwner) { result ->
                                if (!result) {
                                    Snackbar.make(
                                        requireView(),
                                        "There was an error adding this timeslot to your favorites. Try again",
                                        Snackbar.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        }
                        .setNegativeButton("No") { dialog, _ ->
                            dialog.dismiss()
                        }
                        .show()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

operator fun Int.minus(duration: Duration): Int {
    return this-((duration.hours * 60) + duration.minutes)
}
