package it.polito.timebanking

import android.graphics.Canvas
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth

class MyOffersListFragment: Fragment(R.layout.my_offers_list_fragment) {

    private lateinit var timeslotAdapter: TimeSlotAdapter
    val timeSlotVM by viewModels<TimeSlotViewModel> {
        TimeSlotViewModelFactory(requireActivity().application, "All")
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val noOffersTextView = view.findViewById<TextView>(R.id.no_offers_tv)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        val linearLayoutManager = LinearLayoutManager(requireContext())
        recyclerView.layoutManager = linearLayoutManager
        timeslotAdapter = TimeSlotAdapter(this)
        recyclerView.adapter = timeslotAdapter
        ItemTouchHelper(object : ItemTouchHelper.Callback() {
            private val limitScrollX = (100 * resources.displayMetrics.density).toInt()
            private var currentScrollX = 0
            private var currentScrollXWhenInActive = 0
            private var initXWhenInActive = 0f
            private var firstInActive = false
            override fun getMovementFlags(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder): Int {
                val dragFlags = 0
                val swipeFlags = ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
                return makeMovementFlags(dragFlags, swipeFlags)
            }
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean = true
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) { }
            override fun getSwipeThreshold(viewHolder: RecyclerView.ViewHolder): Float {
                return Integer.MAX_VALUE.toFloat()
            }
            override fun getSwipeEscapeVelocity(defaultValue: Float): Float {
                return Integer.MAX_VALUE.toFloat()
            }
            override fun onChildDraw(c: Canvas, recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean) {
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    if (dX == 0f) {
                        currentScrollX = viewHolder.itemView.scrollX
                        firstInActive = true
                    }
                    if (isCurrentlyActive) {
                        var scrollOffset = currentScrollX + (-dX).toInt()
                        if (scrollOffset > limitScrollX) {
                            scrollOffset = limitScrollX
                        }
                        else if (scrollOffset < 0) {
                            scrollOffset = 0
                        }
                        viewHolder.itemView.scrollTo(scrollOffset, 0)
                    }
                    else {
                        if (firstInActive) {
                            firstInActive = false
                            currentScrollXWhenInActive = viewHolder.itemView.scrollX
                            initXWhenInActive = dX
                        }
                        if (viewHolder.itemView.scrollX < limitScrollX) {
                            viewHolder.itemView.scrollTo((currentScrollXWhenInActive * dX / initXWhenInActive).toInt(), 0)
                        }
                    }
                }
            }
            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                if (viewHolder.itemView.scrollX > limitScrollX) {
                    viewHolder.itemView.scrollTo(limitScrollX, 0)
                }
                else if (viewHolder.itemView.scrollX < 0) {
                    viewHolder.itemView.scrollTo(0, 0)
                }
            }
        }).apply {
            attachToRecyclerView(recyclerView)
        }
        val refreshLayout = view.findViewById<SwipeRefreshLayout>(R.id.refresh_layout)
        val orderByLayout = view.findViewById<LinearLayout>(R.id.order_by_layout_timeslot)
        val orderBySpinner = view.findViewById<Spinner>(R.id.order_by_spinner_timeslot)
        ArrayAdapter.createFromResource(requireContext(), R.array.order_by_choices_with_service_type_timeslot, R.layout.simple_item_choice_item)
            .also { orderByAdapter ->
                orderByAdapter.setDropDownViewResource(R.layout.simple_item_choice_item)
                orderBySpinner.adapter = orderByAdapter
            }
        orderBySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(av: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                when (av?.getItemAtPosition(pos).toString()) {
                    resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[0] -> {
                        timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "title").observe(requireParentFragment().viewLifecycleOwner) {
                            if (it != null) {
                                timeslotAdapter.setTimeSlotList(it)
                                if (it.isEmpty()) {
                                    noOffersTextView.visibility = View.VISIBLE
                                    orderByLayout.visibility = View.GONE
                                } else {
                                    noOffersTextView.visibility = View.GONE
                                    orderByLayout.visibility = View.VISIBLE
                                }
                                val position =
                                    (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                recyclerView.scrollToPosition(position)
                            }
                            else {
                                Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                                findNavController().navigateUp()
                            }
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[1] -> {
                        timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "date").observe(requireParentFragment().viewLifecycleOwner) {
                            if (it != null) {
                                timeslotAdapter.setTimeSlotList(it)
                                if (it.isEmpty()) {
                                    noOffersTextView.visibility = View.VISIBLE
                                    orderByLayout.visibility = View.GONE
                                } else {
                                    noOffersTextView.visibility = View.GONE
                                    orderByLayout.visibility = View.VISIBLE
                                }
                                val position =
                                    (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                recyclerView.scrollToPosition(position)
                            }
                            else {
                                Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                                findNavController().navigateUp()
                            }
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[2] -> {
                        timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "location").observe(requireParentFragment().viewLifecycleOwner) {
                            if (it != null) {
                                timeslotAdapter.setTimeSlotList(it)
                                if (it.isEmpty()) {
                                    noOffersTextView.visibility = View.VISIBLE
                                    orderByLayout.visibility = View.GONE
                                } else {
                                    noOffersTextView.visibility = View.GONE
                                    orderByLayout.visibility = View.VISIBLE
                                }
                                val position =
                                    (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                recyclerView.scrollToPosition(position)
                            }
                            else {
                                Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                                findNavController().navigateUp()
                            }
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[3] -> {
                        timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "serviceType").observe(requireParentFragment().viewLifecycleOwner) {
                            if (it != null) {
                                timeslotAdapter.setTimeSlotList(it)
                                if (it.isEmpty()) {
                                    noOffersTextView.visibility = View.VISIBLE
                                    orderByLayout.visibility = View.GONE
                                } else {
                                    noOffersTextView.visibility = View.GONE
                                    orderByLayout.visibility = View.VISIBLE
                                }
                                val position =
                                    (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                recyclerView.scrollToPosition(position)
                            }
                            else {
                                Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                                findNavController().navigateUp()
                            }
                        }
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        refreshLayout.setOnRefreshListener {
            when (orderBySpinner.selectedItem) {
                resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[0] -> {
                    timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "title").observe(this.viewLifecycleOwner) {
                        if (it != null) {
                            timeslotAdapter.setTimeSlotList(it)
                            if (it.isEmpty()) {
                                noOffersTextView.visibility = View.VISIBLE
                                orderByLayout.visibility = View.GONE
                            } else {
                                noOffersTextView.visibility = View.GONE
                                orderByLayout.visibility = View.VISIBLE
                            }
                            refreshLayout.isRefreshing = false
                            val position =
                                (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                        else {
                            Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                            findNavController().navigateUp()
                        }
                    }
                }
                resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[1] -> {
                    timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "date").observe(this.viewLifecycleOwner) {
                        if (it != null) {
                            timeslotAdapter.setTimeSlotList(it)
                            if (it.isEmpty()) {
                                noOffersTextView.visibility = View.VISIBLE
                                orderByLayout.visibility = View.GONE
                            } else {
                                noOffersTextView.visibility = View.GONE
                                orderByLayout.visibility = View.VISIBLE
                            }
                            refreshLayout.isRefreshing = false
                            val position =
                                (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                        else {
                            Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                            findNavController().navigateUp()
                        }
                    }
                }
                resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[2] -> {
                    timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "location").observe(this.viewLifecycleOwner) {
                        if (it != null) {
                            timeslotAdapter.setTimeSlotList(it)
                            if (it.isEmpty()) {
                                noOffersTextView.visibility = View.VISIBLE
                                orderByLayout.visibility = View.GONE
                            } else {
                                noOffersTextView.visibility = View.GONE
                                orderByLayout.visibility = View.VISIBLE
                            }
                            refreshLayout.isRefreshing = false
                            val position =
                                (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                        else {
                            Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                            findNavController().navigateUp()
                        }
                    }
                }
                resources.getStringArray(R.array.order_by_choices_with_service_type_timeslot)[3] -> {
                    timeSlotVM.getTimeslotsCreatedByUser(FirebaseAuth.getInstance().currentUser!!.uid, "serviceType").observe(requireParentFragment().viewLifecycleOwner) {
                        if (it != null) {
                            timeslotAdapter.setTimeSlotList(it)
                            if (it.isEmpty()) {
                                noOffersTextView.visibility = View.VISIBLE
                                orderByLayout.visibility = View.GONE
                            } else {
                                noOffersTextView.visibility = View.GONE
                                orderByLayout.visibility = View.VISIBLE
                            }
                            val position =
                                (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                        else {
                            Snackbar.make(requireView(), "An error occurred retrieving offers!", Snackbar.LENGTH_SHORT).show()
                            findNavController().navigateUp()
                        }
                    }
                }
            }
        }
        setHasOptionsMenu(true)
    }
    fun openDetailsFragment(timeslotId: String) = findNavController().navigate(MyOffersListFragmentDirections.actionMyOffersListFragmentToTimeSlotDetailsFragment(timeslotId, "All"))
    fun openEditFragment(timeslotId: String) = findNavController().navigate(MyOffersListFragmentDirections.actionMyOffersListFragmentToTimeSlotEditFragment(timeslotId, "All"))
}