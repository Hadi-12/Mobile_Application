package it.polito.timebanking

import android.graphics.Canvas
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.*
import androidx.appcompat.widget.SearchView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class TimeSlotListFragment: Fragment(R.layout.timeslot_list_fragment_layout) {
    private val args: TimeSlotListFragmentArgs by navArgs()
    private lateinit var adapter: TimeSlotAdapter
    val timeSlotVM by viewModels<TimeSlotViewModel> {
        TimeSlotViewModelFactory(requireActivity().application, args.serviceType)
    }
    private val userVM by viewModels<UserViewModel>()
    private lateinit var topAppBar: MaterialToolbar
    private lateinit var refreshLayout: SwipeRefreshLayout
    private lateinit var orderBySpinner: Spinner
    private lateinit var orderByLayout: LinearLayout
    private lateinit var noTimeSlotsLayout: ConstraintLayout
    private lateinit var recyclerView: RecyclerView
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val fab = view.findViewById<FloatingActionButton>(R.id.floating_action_button)
        userVM.getUser(Firebase.auth.currentUser!!.uid).observe(this.viewLifecycleOwner) {
            if (it != null) {
                fab.visibility = VISIBLE
                if (it.skills.contains(args.serviceType)) {
                    fab.setOnClickListener {
                        findNavController().navigate(TimeSlotListFragmentDirections.actionTimeSlotListFragmentToTimeSlotEditFragment(null, args.serviceType))
                    }
                }
                else {
                    fab.setOnClickListener { _ ->
                        MaterialAlertDialogBuilder(requireContext())
                            .setTitle("Wait!")
                            .setMessage("You don't have ${args.serviceType} among your skills. Do you want to add it and proceed?")
                            .setPositiveButton("Yes") { dialogInterface, _ ->
                                val skills = it.skills.toMutableList()
                                skills += args.serviceType
                                val newUser = User(
                                    it.profile_picture,
                                    it.fullname,
                                    it.nickname,
                                    it.email,
                                    it.location,
                                    skills
                                )
                                userVM.setUser(Firebase.auth.currentUser!!.uid, newUser, null).observe(this.viewLifecycleOwner) { result ->
                                    if (result) {
                                        findNavController().navigate(TimeSlotListFragmentDirections.actionTimeSlotListFragmentToTimeSlotEditFragment(null, args.serviceType))
                                    }
                                    else {
                                        Snackbar.make(requireView(), "There was an error adding the skill to your profile. Try adding explicitly editing your profile", Snackbar.LENGTH_SHORT).show()
                                        dialogInterface.dismiss()
                                    }
                                }
                            }
                            .setNegativeButton("No") { dialogInterface, _ ->
                                dialogInterface.dismiss()
                            }
                            .setNeutralButton("Cancel") { dialogInterface, _ ->
                                dialogInterface.dismiss()
                            }
                            .show()
                    }
                }
            }
            else {
                Snackbar.make(requireView(), "An error occurred", Snackbar.LENGTH_SHORT).show()
            }
        }
        topAppBar = requireActivity().findViewById(R.id.topAppBar) as MaterialToolbar
        topAppBar.title = "${args.serviceType} Timeslots"
        noTimeSlotsLayout = view.findViewById(R.id.no_timeslots_layout)
        recyclerView = view.findViewById(R.id.recycler_view)
        val linearLayoutManager = LinearLayoutManager(requireContext())
        recyclerView.layoutManager = linearLayoutManager
        adapter = TimeSlotAdapter(this)
        recyclerView.adapter = adapter
        ItemTouchHelper(object : ItemTouchHelper.Callback() {

            private val limitScrollX = (100 * resources.displayMetrics.density).toInt()
            private var currentScrollX = 0
            private var currentScrollXWhenInActive = 0
            private var initXWhenInActive = 0f
            private var firstInActive = false

            override fun getMovementFlags(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder): Int {
                val dragFlags = 0
                val swipeFlags = ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
                return makeMovementFlags(dragFlags, swipeFlags)
            }

            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean = true

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {

            }

            override fun getSwipeThreshold(viewHolder: RecyclerView.ViewHolder): Float {
                return Integer.MAX_VALUE.toFloat()
            }

            override fun getSwipeEscapeVelocity(defaultValue: Float): Float {
                return Integer.MAX_VALUE.toFloat()
            }

            override fun onChildDraw(c: Canvas, recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean) {
                if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
                    if (dX == 0f) {
                        currentScrollX = viewHolder.itemView.scrollX
                        firstInActive = true
                    }
                    if (isCurrentlyActive) {
                        var scrollOffset = currentScrollX + (-dX).toInt()
                        if (scrollOffset > limitScrollX) {
                            scrollOffset = limitScrollX
                        }
                        else if (scrollOffset < 0) {
                            scrollOffset = 0
                        }
                        viewHolder.itemView.scrollTo(scrollOffset, 0)
                    }
                    else {
                        if (firstInActive) {
                            firstInActive = false
                            currentScrollXWhenInActive = viewHolder.itemView.scrollX
                            initXWhenInActive = dX
                        }
                        if (viewHolder.itemView.scrollX < limitScrollX) {
                            viewHolder.itemView.scrollTo((currentScrollXWhenInActive * dX / initXWhenInActive).toInt(), 0)
                        }
                    }
                }
            }

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                if (viewHolder.itemView.scrollX > limitScrollX) {
                    viewHolder.itemView.scrollTo(limitScrollX, 0)
                }
                else if (viewHolder.itemView.scrollX < 0) {
                    viewHolder.itemView.scrollTo(0, 0)
                }
            }
        }).apply {
            attachToRecyclerView(recyclerView)
        }
        orderBySpinner = view.findViewById(R.id.order_by_spinner_timeslot)
        ArrayAdapter.createFromResource(requireContext(), R.array.order_by_choices_timeslot, R.layout.simple_item_choice_item)
            .also { orderByAdapter ->
                orderByAdapter.setDropDownViewResource(R.layout.simple_item_choice_item)
                orderBySpinner.adapter = orderByAdapter
            }
        orderByLayout = view.findViewById(R.id.order_by_layout_timeslot)
        orderBySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(av: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                when (av?.getItemAtPosition(pos).toString()) {
                    resources.getStringArray(R.array.order_by_choices_timeslot)[0] -> {
                        timeSlotVM.getOrderedByTitle().observe(requireParentFragment().viewLifecycleOwner) {
                            adapter.setTimeSlotList(it)
                            if(it.isEmpty()) {
                                noTimeSlotsLayout.visibility = VISIBLE
                                orderByLayout.visibility = GONE
                            }
                            else {
                                noTimeSlotsLayout.visibility = GONE
                                orderByLayout.visibility = VISIBLE
                            }
                            val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_timeslot)[1] -> {
                        timeSlotVM.getOrderedByDate().observe(requireParentFragment().viewLifecycleOwner) {
                            adapter.setTimeSlotList(it)
                            if(it.isEmpty()) {
                                noTimeSlotsLayout.visibility = VISIBLE
                                orderByLayout.visibility = GONE
                            }
                            else {
                                noTimeSlotsLayout.visibility = GONE
                                orderByLayout.visibility = VISIBLE
                            }
                            val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_timeslot)[2] -> {
                        timeSlotVM.getOrderedByLocation().observe(requireParentFragment().viewLifecycleOwner) {
                            adapter.setTimeSlotList(it)
                            if(it.isEmpty()) {
                                noTimeSlotsLayout.visibility = VISIBLE
                                orderByLayout.visibility = GONE
                            }
                            else {
                                noTimeSlotsLayout.visibility = GONE
                                orderByLayout.visibility = VISIBLE
                            }
                            val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        }
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        refreshLayout = view.findViewById(R.id.refresh_layout)
        refreshLayout.setOnRefreshListener {
            when (orderBySpinner.selectedItem) {
                resources.getStringArray(R.array.order_by_choices_timeslot)[0] -> {
                    timeSlotVM.getOrderedByTitle().observe(this.viewLifecycleOwner) {
                        adapter.setTimeSlotList(it)
                        if(it.isEmpty()) {
                            noTimeSlotsLayout.visibility = VISIBLE
                            orderByLayout.visibility = GONE
                        }
                        else {
                            noTimeSlotsLayout.visibility = GONE
                            orderByLayout.visibility = VISIBLE
                        }
                        refreshLayout.isRefreshing = false
                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                        recyclerView.scrollToPosition(position)
                    }
                }
                resources.getStringArray(R.array.order_by_choices_timeslot)[1] -> {
                    timeSlotVM.getOrderedByDate().observe(this.viewLifecycleOwner) {
                        adapter.setTimeSlotList(it)
                        if(it.isEmpty()) {
                            noTimeSlotsLayout.visibility = VISIBLE
                            orderByLayout.visibility = GONE
                        }
                        else {
                            noTimeSlotsLayout.visibility = GONE
                            orderByLayout.visibility = VISIBLE
                        }
                        refreshLayout.isRefreshing = false
                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                        recyclerView.scrollToPosition(position)
                    }
                }
                resources.getStringArray(R.array.order_by_choices_timeslot)[2] -> {
                    timeSlotVM.getOrderedByLocation().observe(this.viewLifecycleOwner) {
                        adapter.setTimeSlotList(it)
                        if(it.isEmpty()) {
                            noTimeSlotsLayout.visibility = VISIBLE
                            orderByLayout.visibility = GONE
                        }
                        else {
                            noTimeSlotsLayout.visibility = GONE
                            orderByLayout.visibility = VISIBLE
                        }
                        refreshLayout.isRefreshing = false
                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                        recyclerView.scrollToPosition(position)
                    }
                }
            }
        }
        setHasOptionsMenu(true)
    }
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.search_menu, menu)
        val searchItem: MenuItem = menu.findItem(R.id.actionSearch)
        // getting search view of our item.
        val searchView = searchItem.actionView as SearchView
        val searchEditText =
            searchView.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)
        requireContext().let {
            searchEditText.setTextColor( ContextCompat.getColor(it, R.color.white))
            searchEditText.setHintTextColor(ContextCompat.getColor(it, R.color.white))
        }
        // below line is to call set on query text listener method.
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    timeSlotVM.getOrderedByTitle().observe(requireParentFragment().viewLifecycleOwner)  {
                            adapter.setTimeSlotList(it)
                            adapter.addFilter(newText)
                        }
                }
                else{
                    timeSlotVM.getOrderedByTitle().observe(requireParentFragment().viewLifecycleOwner) {
                        adapter.setTimeSlotList(it)

                    }
                }

                return false
            }
        })

    }
    fun openDetailsFragment(timeslotId: String) = findNavController().navigate(TimeSlotListFragmentDirections.actionTimeSlotListFragmentToTimeSlotDetailsFragment(timeslotId, args.serviceType))
    fun openEditFragment(timeslotId: String) = findNavController().navigate(TimeSlotListFragmentDirections.actionTimeSlotListFragmentToTimeSlotEditFragment(timeslotId, args.serviceType))
    fun goToUserAction(userID: String) = findNavController().navigate(TimeSlotListFragmentDirections.actionTimeSlotListFragmentToShowProfileFragment(userID))
    fun favoriteAction(timeslot: TimeSlot) {
        if (timeslot.interestedUsers.contains(FirebaseAuth.getInstance().currentUser!!.uid)) {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Remove from favorites?")
                .setMessage("Do you want to remove this offer from your favorites?")
                .setPositiveButton("Yes") { _, _ ->
                    timeSlotVM.switchInterestedUserToTimeslot(
                        timeslot.id!!,
                        FirebaseAuth.getInstance().currentUser!!.uid
                    ).observe(viewLifecycleOwner) { result ->
                        if (!result) {
                            Snackbar.make(
                                requireView(),
                                "There was an error removing this timeslot to your favorites. Try again",
                                Snackbar.LENGTH_SHORT
                            ).show()
                        } else {
                            refreshLayout.post { refreshLayout.isRefreshing = true }
                            when (orderBySpinner.selectedItem) {
                                resources.getStringArray(R.array.order_by_choices_timeslot)[0] -> {
                                    timeSlotVM.getOrderedByTitle().observe(this.viewLifecycleOwner) {
                                        adapter.setTimeSlotList(it)
                                        if(it.isEmpty()) {
                                            noTimeSlotsLayout.visibility = VISIBLE
                                            orderByLayout.visibility = GONE
                                        }
                                        else {
                                            noTimeSlotsLayout.visibility = GONE
                                            orderByLayout.visibility = VISIBLE
                                        }
                                        refreshLayout.isRefreshing = false
                                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                        recyclerView.scrollToPosition(position)
                                    }
                                }
                                resources.getStringArray(R.array.order_by_choices_timeslot)[1] -> {
                                    timeSlotVM.getOrderedByDate().observe(this.viewLifecycleOwner) {
                                        adapter.setTimeSlotList(it)
                                        if(it.isEmpty()) {
                                            noTimeSlotsLayout.visibility = VISIBLE
                                            orderByLayout.visibility = GONE
                                        }
                                        else {
                                            noTimeSlotsLayout.visibility = GONE
                                            orderByLayout.visibility = VISIBLE
                                        }
                                        refreshLayout.isRefreshing = false
                                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                        recyclerView.scrollToPosition(position)
                                    }
                                }
                                resources.getStringArray(R.array.order_by_choices_timeslot)[2] -> {
                                    timeSlotVM.getOrderedByLocation().observe(this.viewLifecycleOwner) {
                                        adapter.setTimeSlotList(it)
                                        if(it.isEmpty()) {
                                            noTimeSlotsLayout.visibility = VISIBLE
                                            orderByLayout.visibility = GONE
                                        }
                                        else {
                                            noTimeSlotsLayout.visibility = GONE
                                            orderByLayout.visibility = VISIBLE
                                        }
                                        refreshLayout.isRefreshing = false
                                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                        recyclerView.scrollToPosition(position)
                                    }
                                }
                            }
                        }
                    }
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        } else {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Add to favorites?")
                .setMessage("Do you want to add this offer to your favorites?")
                .setPositiveButton("Yes") { _, _ ->
                    timeSlotVM.switchInterestedUserToTimeslot(
                        timeslot.id!!,
                        FirebaseAuth.getInstance().currentUser!!.uid
                    ).observe(viewLifecycleOwner) { result ->
                        if (!result) {
                            Snackbar.make(
                                requireView(),
                                "There was an error adding this timeslot to your favorites. Try again",
                                Snackbar.LENGTH_SHORT
                            ).show()
                        } else {
                            refreshLayout.post { refreshLayout.isRefreshing = true }
                            when (orderBySpinner.selectedItem) {
                                resources.getStringArray(R.array.order_by_choices_timeslot)[0] -> {
                                    timeSlotVM.getOrderedByTitle().observe(this.viewLifecycleOwner) {
                                        adapter.setTimeSlotList(it)
                                        if(it.isEmpty()) {
                                            noTimeSlotsLayout.visibility = VISIBLE
                                            orderByLayout.visibility = GONE
                                        }
                                        else {
                                            noTimeSlotsLayout.visibility = GONE
                                            orderByLayout.visibility = VISIBLE
                                        }
                                        refreshLayout.isRefreshing = false
                                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                        recyclerView.scrollToPosition(position)
                                    }
                                }
                                resources.getStringArray(R.array.order_by_choices_timeslot)[1] -> {
                                    timeSlotVM.getOrderedByDate().observe(this.viewLifecycleOwner) {
                                        adapter.setTimeSlotList(it)
                                        if(it.isEmpty()) {
                                            noTimeSlotsLayout.visibility = VISIBLE
                                            orderByLayout.visibility = GONE
                                        }
                                        else {
                                            noTimeSlotsLayout.visibility = GONE
                                            orderByLayout.visibility = VISIBLE
                                        }
                                        refreshLayout.isRefreshing = false
                                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                        recyclerView.scrollToPosition(position)
                                    }
                                }
                                resources.getStringArray(R.array.order_by_choices_timeslot)[2] -> {
                                    timeSlotVM.getOrderedByLocation().observe(this.viewLifecycleOwner) {
                                        adapter.setTimeSlotList(it)
                                        if(it.isEmpty()) {
                                            noTimeSlotsLayout.visibility = VISIBLE
                                            orderByLayout.visibility = GONE
                                        }
                                        else {
                                            noTimeSlotsLayout.visibility = GONE
                                            orderByLayout.visibility = VISIBLE
                                        }
                                        refreshLayout.isRefreshing = false
                                        val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                        recyclerView.scrollToPosition(position)
                                    }
                                }
                            }
                        }
                    }
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }
    }
}