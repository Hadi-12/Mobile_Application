package it.polito.timebanking

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat.is24HourFormat
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.*
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.DateValidatorPointForward
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.google.firebase.Timestamp
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class TimeSlotEditFragment: Fragment(R.layout.timeslot_edit_fragment_layout) {
    private val timeSlotVM by viewModels<TimeSlotViewModel> {
        TimeSlotViewModelFactory(requireActivity().application, args.serviceType)
    }
    private val userViewModel by viewModels<UserViewModel>()
    private val args: TimeSlotEditFragmentArgs by navArgs()
    private lateinit var topAppBar: MaterialToolbar
    private lateinit var titleEditText: TextInputLayout
    private lateinit var descriptionEditText: TextInputLayout
    private lateinit var serviceTypeEditText: TextInputLayout
    private lateinit var dateEditText: TextInputLayout
    private lateinit var timeEditText: TextInputLayout
    private lateinit var durationEditText: TextInputLayout
    private lateinit var locationEditText: TextInputLayout
    private lateinit var titleValidator: ValidationTextWatcher
    private lateinit var descriptionValidator: ValidationTextWatcher
    private lateinit var serviceTypeValidator: ValidationTextWatcher
    private lateinit var dateValidator: ValidationTextWatcher
    private lateinit var timeValidator: ValidationTextWatcher
    private lateinit var durationValidator: ValidationTextWatcher
    private lateinit var locationValidator: ValidationTextWatcher
    private var timeslotId: String? = ""
    private var selectedDuration: Duration? = null
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        topAppBar = requireActivity().findViewById(R.id.topAppBar) as MaterialToolbar
        titleEditText = view.findViewById(R.id.title_timeslot_edit_input_layout)
        descriptionEditText = view.findViewById(R.id.description_timeslot_edit_input_layout)
        serviceTypeEditText = view.findViewById(R.id.service_type_timeslot_edit_input_layout)
        val user = userViewModel.getUser(Firebase.auth.currentUser!!.uid)
        user.observe(this.viewLifecycleOwner) {
            if(it!!.skills.isNotEmpty()) {
                val adapter =
                    ArrayAdapter(requireContext(), R.layout.simple_item_choice_item, it.skills)
                (serviceTypeEditText.editText as? AutoCompleteTextView)?.setAdapter(adapter)
                (serviceTypeEditText.editText as? AutoCompleteTextView)?.onItemClickListener = AdapterView.OnItemClickListener { parent, _, position, _ ->
                    if (parent.getItemAtPosition(position).toString() != serviceTypeValidator.originalText)
                        serviceTypeValidator.changedSomething = true
                }
            }
            else {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Skills required!")
                    .setMessage("You need at least a skill in your profile in order to create an offer")
                    .setNeutralButton("Cancel") { _, _ ->
                        findNavController().navigateUp()
                    }
                    .setPositiveButton("Edit profile") { _, _ ->
                        findNavController().navigate(TimeSlotEditFragmentDirections.actionTimeSlotEditFragmentToEditProfileFragment())
                    }
                    .setCancelable(false)
                    .show()
            }
        }
        timeEditText = view.findViewById(R.id.time_timeslot_edit_input_layout)
        timeEditText.editText?.setOnFocusChangeListener { _, b ->
            if (b) {
                val cal = Calendar.getInstance()
                val isSystem24Hour = is24HourFormat(activity)
                val clockFormat = if (isSystem24Hour) TimeFormat.CLOCK_24H else TimeFormat.CLOCK_12H
                if (timeEditText.editText?.text.toString().isNotEmpty()) {
                    cal.time = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT)
                        .parse(timeEditText.editText?.text.toString()) as Date
                }
                val hour = cal.get(Calendar.HOUR_OF_DAY)
                val minute = cal.get(Calendar.MINUTE)
                val timePicker = MaterialTimePicker.Builder()
                    .setTimeFormat(clockFormat)
                    .setHour(hour)
                    .setMinute(minute)
                    .setTitleText("Select time")
                    .build()
                timePicker.show(parentFragmentManager, "timePickerTag")
                timePicker.addOnPositiveButtonClickListener {
                    cal.set(Calendar.HOUR_OF_DAY, timePicker.hour)
                    cal.set(Calendar.MINUTE, timePicker.minute)
                    timeEditText.editText?.setText(
                        SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(cal.time)
                    )
                    durationEditText.editText?.requestFocus()
                }
                timePicker.addOnNegativeButtonClickListener {
                    durationEditText.editText?.requestFocus()
                }
                timePicker.addOnCancelListener {
                    durationEditText.editText?.requestFocus()
                }
            }
        }
        dateEditText = view.findViewById(R.id.date_timeslot_edit_input_layout)
        dateEditText.editText?.setOnFocusChangeListener { _, b ->
            if (b) {
                var selection = MaterialDatePicker.todayInUtcMilliseconds()
                if (dateEditText.editText?.text.toString().isNotEmpty()) {
                    val c = Calendar.getInstance()
                    c.time = SimpleDateFormat.getDateInstance()
                        .parse(dateEditText.editText?.text.toString()) as Date
                    selection = c.timeInMillis
                }
                val datePicker = MaterialDatePicker.Builder.datePicker()
                    .setTitleText("Select date")
                    .setSelection(selection)
                    .setCalendarConstraints(
                        CalendarConstraints.Builder()
                            .setValidator(DateValidatorPointForward.now())
                            .build()
                    )
                    .build()
                datePicker.show(parentFragmentManager, "datePickerTag")
                datePicker.addOnPositiveButtonClickListener {
                    val cal = Calendar.getInstance()
                    cal.timeInMillis = datePicker.selection as Long
                    dateEditText.editText?.setText(
                        SimpleDateFormat.getDateInstance().format(cal.time)
                    )
                    timeEditText.editText?.requestFocus()
                }
                datePicker.addOnNegativeButtonClickListener {
                    timeEditText.editText?.requestFocus()
                }
                datePicker.addOnCancelListener {
                    timeEditText.editText?.requestFocus()
                }
            }
        }
        durationEditText = view.findViewById(R.id.duration_timeslot_edit_input_layout)
        durationEditText.editText?.setOnFocusChangeListener { _, b ->
            if (b) {
                val dialogView = layoutInflater.inflate(R.layout.duration_view, durationEditText as ViewGroup, false)
                val hourNumberPicker = dialogView.findViewById<NumberPicker>(R.id.hours_duration_number_picker)
                hourNumberPicker.minValue = 0
                hourNumberPicker.maxValue = 23
                val minutesNumberPicker = dialogView.findViewById<NumberPicker>(R.id.minutes_duration_number_picker)
                minutesNumberPicker.minValue = 0
                val values = (0..55 step 5).map { it.toString() }.toTypedArray()
                minutesNumberPicker.maxValue = values.size - 1
                minutesNumberPicker.displayedValues = values
                if (selectedDuration != null) {
                    hourNumberPicker.value = selectedDuration!!.hours
                    minutesNumberPicker.value = selectedDuration!!.minutes / 5
                }
                val durationError = dialogView.findViewById<TextView>(R.id.duration_error_picker)
                val dialog = MaterialAlertDialogBuilder(requireContext())
                    .setView(dialogView)
                    .setPositiveButton("Ok") { _, _ ->

                    }
                    .setNegativeButton("Cancel") { dialog, _ ->
                        dialog.dismiss()
                        locationEditText.editText?.requestFocus()
                    }
                    .setOnCancelListener {
                        locationEditText.editText?.requestFocus()
                    }
                    .show()
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    if (hourNumberPicker.value == 0 && minutesNumberPicker.value == 0) {
                        durationError.visibility = VISIBLE
                    } else {
                        durationError.visibility = GONE
                        selectedDuration = Duration(hours = hourNumberPicker.value, minutes = minutesNumberPicker.value * 5)
                        dialog.dismiss()
                        durationEditText.editText?.setText(selectedDuration!!.representAsString())
                        locationEditText.editText?.requestFocus()
                    }
                }
            }
        }
        locationEditText = view.findViewById(R.id.location_timeslot_edit_input_layout)
        timeslotId = args.timeslotId
        if (timeslotId != null) {
            val timeSlot = timeSlotVM.getTimeSlot(timeslotId!!)
            timeSlot.observe(this.viewLifecycleOwner) {
                if(it == null) {
                    return@observe
                }
                if (savedInstanceState == null) {
                    titleEditText.editText?.setText(it.title)
                    descriptionEditText.editText?.setText(it.description)
                    serviceTypeEditText.editText?.setText(it.serviceType)
                    dateEditText.editText?.setText(SimpleDateFormat.getDateInstance().format(it.date.toDate()))
                    timeEditText.editText?.setText(SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).format(it.date.toDate()))
                    durationEditText.editText?.setText(it.duration.representAsString())
                    selectedDuration = it.duration
                    locationEditText.editText?.setText(it.location)
                }
                titleValidator = ValidationTextWatcher(titleEditText, it.title)
                titleEditText.editText?.addTextChangedListener(titleValidator)
                descriptionValidator = ValidationTextWatcher(descriptionEditText, it.description)
                descriptionEditText.editText?.addTextChangedListener(descriptionValidator)
                serviceTypeValidator = ValidationTextWatcher(serviceTypeEditText, it.serviceType)
                dateValidator = ValidationTextWatcher(dateEditText, SimpleDateFormat.getDateInstance().format(it.date.toDate()))
                dateEditText.editText?.addTextChangedListener(dateValidator)
                timeValidator = ValidationTextWatcher(timeEditText, SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).format(it.date.toDate()))
                timeEditText.editText?.addTextChangedListener(timeValidator)
                durationValidator = ValidationTextWatcher(durationEditText, it.duration.representAsString())
                durationEditText.editText?.addTextChangedListener(durationValidator)
                locationValidator = ValidationTextWatcher(locationEditText, it.location)
                locationEditText.editText?.addTextChangedListener(locationValidator)
            }
        }
        else {
            topAppBar.title = "New timeslot"
            titleValidator = ValidationTextWatcher(titleEditText, "")
            titleEditText.editText?.addTextChangedListener(titleValidator)
            descriptionValidator = ValidationTextWatcher(descriptionEditText, "")
            descriptionEditText.editText?.addTextChangedListener(descriptionValidator)
            serviceTypeValidator = ValidationTextWatcher(serviceTypeEditText, "")
            dateValidator = ValidationTextWatcher(dateEditText, "")
            dateEditText.editText?.addTextChangedListener(dateValidator)
            timeValidator = ValidationTextWatcher(timeEditText, "")
            timeEditText.editText?.addTextChangedListener(timeValidator)
            durationValidator = ValidationTextWatcher(durationEditText, "")
            durationEditText.editText?.addTextChangedListener(durationValidator)
            locationValidator = ValidationTextWatcher(locationEditText, "")
            locationEditText.editText?.addTextChangedListener(locationValidator)
            if (savedInstanceState == null) {
                serviceTypeEditText.editText?.setText(args.serviceType)
            }
        }
        setHasOptionsMenu(true)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            backRoutine()
        }
    }

    private fun backRoutine() {
        val changedSomething: Boolean = titleValidator.changedSomething ||
                                        descriptionValidator.changedSomething ||
                                        serviceTypeValidator.changedSomething ||
                                        dateValidator.changedSomething ||
                                        timeValidator.changedSomething ||
                                        durationValidator.changedSomething ||
                                        locationValidator.changedSomething
        if(changedSomething) {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Wait!")
                .setMessage("Do you want to save before leaving?")
                .setNeutralButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                }
                .setNegativeButton("No") { _, _ ->
                    findNavController().navigateUp()
                }
                .setPositiveButton("Yes") { _, _ ->
                    if (validateForm()) {
                        val dateDate = SimpleDateFormat.getDateInstance().parse(dateEditText.editText?.text.toString())
                        val timeDate = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).parse(timeEditText.editText?.text.toString())
                        val date = Date()
                        date.time = dateDate?.time!! + timeDate?.time!!
                        val timestamp = Timestamp(date)
                        val timeSlot = TimeSlot(
                            id = timeslotId,
                            userID = Firebase.auth.currentUser!!.uid,
                            title = titleEditText.editText?.text.toString(),
                            description = descriptionEditText.editText?.text.toString(),
                            serviceType = serviceTypeEditText.editText?.text.toString(),
                            date = timestamp,
                            duration = durationEditText.editText?.text.toString().toDuration()!!,
                            location = locationEditText.editText?.text.toString(),
                        )
                        timeSlotVM.setTimeSlot(timeSlot).observe(this.viewLifecycleOwner) { result ->
                            if (result) {
                                if (timeslotId == null) {
                                    Snackbar.make(requireView(), "Timeslot advertisement successfully created", Snackbar.LENGTH_SHORT).show()
                                }
                                else {
                                    Snackbar.make(requireView(), "Timeslot advertisement successfully updated", Snackbar.LENGTH_SHORT).show()
                                }
                            } else {
                                Snackbar.make(requireView(), "Timeslot setting/updating failed", Snackbar.LENGTH_SHORT).show()
                            }
                            findNavController().navigateUp()
                        }
                    }
                    else {
                        Snackbar.make(view as View, "Make sure to correct all the errors in the form", Snackbar.LENGTH_LONG).show()
                    }
                }
                .show()
        }
        else {
            findNavController().navigateUp()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("title", titleEditText.editText?.text.toString())
        outState.putString("description", descriptionEditText.editText?.text.toString())
        outState.putString("service_type", serviceTypeEditText.editText?.text.toString())
        outState.putString("date", dateEditText.editText?.text.toString())
        outState.putString("time", timeEditText.editText?.text.toString())
        outState.putString("location", locationEditText.editText?.text.toString())
        if (selectedDuration != null)
            outState.putString("selectedDuration", selectedDuration!!.representAsString())
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        if (savedInstanceState != null) {
            titleEditText.editText?.setText(savedInstanceState.getString("title"))
            descriptionEditText.editText?.setText(savedInstanceState.getString("description"))
            serviceTypeEditText.editText?.setText(savedInstanceState.getString("service_type"))
            dateEditText.editText?.setText(savedInstanceState.getString("date"))
            timeEditText.editText?.setText(savedInstanceState.getString("time"))
            locationEditText.editText?.setText(savedInstanceState.getString("location"))
            val previousSelectedDuration = savedInstanceState.getString("selectedDuration")
            if (previousSelectedDuration != null) {
                selectedDuration = previousSelectedDuration.toDuration()
                durationEditText.editText?.setText(previousSelectedDuration)
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.save_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                backRoutine()
                true
            }
            R.id.save_menu_item -> {
                if (validateForm()) {
                    val dateDate = SimpleDateFormat.getDateInstance().parse(dateEditText.editText?.text.toString())
                    val timeDate = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).parse(timeEditText.editText?.text.toString())
                    val date = Date()
                    date.time = dateDate?.time!! + timeDate?.time!!
                    val timestamp = Timestamp(date)
                    val timeSlot = TimeSlot(
                        id = timeslotId,
                        userID = Firebase.auth.currentUser!!.uid,
                        title = titleEditText.editText?.text.toString(),
                        description = descriptionEditText.editText?.text.toString(),
                        serviceType = serviceTypeEditText.editText?.text.toString(),
                        date = timestamp,
                        duration = durationEditText.editText?.text.toString().toDuration()!!,
                        location = locationEditText.editText?.text.toString()
                    )
                    timeSlotVM.setTimeSlot(timeSlot).observe(this.viewLifecycleOwner) { result ->
                        if (result) {
                            if (timeslotId == null) {
                                Snackbar.make(requireView(), "Timeslot advertisement successfully created", Snackbar.LENGTH_SHORT).show()
                            }
                            else {
                                Snackbar.make(requireView(), "Timeslot advertisement successfully updated", Snackbar.LENGTH_SHORT).show()
                            }
                        } else {
                            Snackbar.make(requireView(), "Timeslot setting/updating failed", Snackbar.LENGTH_SHORT).show()
                        }
                        findNavController().navigateUp()
                    }
                }
                else {
                    Snackbar.make(view as View, "Make sure to correct all the errors in the form", Snackbar.LENGTH_LONG).show()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun validateForm(): Boolean {
        return  titleValidator.check() &&
                descriptionValidator.check() &&
                serviceTypeValidator.check() &&
                dateValidator.check() &&
                timeValidator.check() &&
                durationValidator.check() &&
                locationValidator.check()
    }


}

class ValidationTextWatcher(_view: TextInputLayout, val originalText: String): TextWatcher {
    private val view: TextInputLayout = _view
    var changedSomething: Boolean = false
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }

    fun check(): Boolean {
        when (view.id) {
            R.id.title_timeslot_edit_input_layout -> {
                return if (view.editText?.text.toString().isEmpty()) {
                    view.error = "Title must not be empty"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
            R.id.description_timeslot_edit_input_layout -> {
                return if (view.editText?.text.toString().length < 30) {
                    view.error = "Description must be at least 30 characters long"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
            R.id.service_type_timeslot_edit_input_layout -> {
                return if (view.editText?.text.toString().isEmpty()) {
                    view.error = "Select a service type"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
            R.id.date_timeslot_edit_input_layout -> {
                if (view.editText?.text.toString().isEmpty()) {
                    view.error = "Date must not be empty"
                    view.isErrorEnabled = true
                    return false
                }
                else {
                    view.error = ""
                    view.isErrorEnabled = false
                }
                val timeTextInputLayout = (view.parent as View).findViewById<TextInputLayout>(R.id.time_timeslot_edit_input_layout)
                if (timeTextInputLayout.editText?.text.toString().isNotEmpty()) {
                    val timeSelected = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).parse(timeTextInputLayout.editText?.text.toString())
                    if (timeSelected != null) {
                        val cal = Calendar.getInstance()
                        cal.time = timeSelected
                        val dateSelected = SimpleDateFormat.getDateInstance().parse(view.editText?.text.toString())
                        if (dateSelected != null) {
                            var cal2 = Calendar.getInstance()
                            cal2.time = dateSelected
                            cal.set(Calendar.YEAR, cal2.get(Calendar.YEAR))
                            cal.set(Calendar.MONTH, cal2.get(Calendar.MONTH))
                            cal.set(Calendar.DAY_OF_MONTH, cal2.get(Calendar.DAY_OF_MONTH))
                            cal2 = Calendar.getInstance()
                            return if (cal.before(cal2)) {
                                view.error = "Selected time and date must be in the future"
                                timeTextInputLayout.error = "Selected time and date must be in the future"
                                view.isErrorEnabled = true
                                timeTextInputLayout.isErrorEnabled = true
                                false
                            } else {
                                view.error = ""
                                timeTextInputLayout.error = ""
                                view.isErrorEnabled = false
                                timeTextInputLayout.isErrorEnabled = false
                                true
                            }
                        }
                    }
                }
                return true
            }
            R.id.time_timeslot_edit_input_layout -> {
                if (view.editText?.text.toString().isEmpty()) {
                    view.error = "Time must not be empty"
                    view.isErrorEnabled = true
                    return false
                }
                else {
                    view.error = ""
                    view.isErrorEnabled = false
                }
                val dateTextInputLayout = (view.parent as View).findViewById<TextInputLayout>(R.id.date_timeslot_edit_input_layout)
                if (dateTextInputLayout.editText?.text.toString().isNotEmpty()) {
                    val dateSelected = SimpleDateFormat.getDateInstance()
                        .parse(dateTextInputLayout.editText?.text.toString())
                    if (dateSelected != null) {
                        val cal = Calendar.getInstance()
                        cal.time = dateSelected
                        val timeSelected = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT)
                            .parse(view.editText?.text.toString())
                        if (timeSelected != null) {
                            var cal2 = Calendar.getInstance()
                            cal2.time = timeSelected
                            cal.set(Calendar.HOUR_OF_DAY, cal2.get(Calendar.HOUR_OF_DAY))
                            cal.set(Calendar.MINUTE, cal2.get(Calendar.MINUTE))
                            cal2 = Calendar.getInstance()
                            return if (cal.before(cal2)) {
                                view.error = "Selected time and date must be in the future"
                                dateTextInputLayout.error = "Selected time and date must be in the future"
                                view.isErrorEnabled = true
                                dateTextInputLayout.isErrorEnabled = true
                                false
                            } else {
                                view.error = ""
                                dateTextInputLayout.error = ""
                                view.isErrorEnabled = false
                                dateTextInputLayout.isErrorEnabled = false
                                true
                            }
                        }
                    }
                }
                return true
            }
            R.id.duration_timeslot_edit_input_layout -> {
                return if (view.editText?.text.toString().isEmpty()) {
                    view.error = "Duration must not be empty"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
            R.id.location_timeslot_edit_input_layout -> {
                return if (view.editText?.text.toString().isEmpty()) {
                    view.error = "Location must not be empty"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
        }
        return false
    }

    override fun afterTextChanged(p0: Editable?) {
        changedSomething = originalText != view.editText?.text.toString()
        check()
    }

}