package it.polito.timebanking

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat
import java.util.*

class MessageAdapter(val fragment: ChatFragment, private val usersViewModel: UserViewModel, val context: Context) : RecyclerView.Adapter<MessageAdapter.MessageItemHolder>() {
	class MessageItemHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
		fun bind(chat: Chat, context: Context, usersViewModel: UserViewModel, lifecycleOwner: LifecycleOwner) {
			if (chat.text != null) {
				val tv = itemView.findViewById<TextView>(R.id.msg_text_chat)
				tv.text = chat.text
				tv.visibility = VISIBLE
			}
			else {
				itemView.findViewById<TextView>(R.id.msg_text_chat).visibility = GONE
			}
			if (chat.attachment != null) {
				itemView.findViewById<ImageView>(R.id.image_chat).visibility = VISIBLE
				Glide.with(context).load(chat.attachment).into(itemView.findViewById(R.id.image_chat))
			}
			else {
				itemView.findViewById<ImageView>(R.id.image_chat).visibility = GONE
			}
			val cal1 = Calendar.getInstance()
			val cal2 = Calendar.getInstance()
			cal2.time = chat.timestamp
			val sameDay = cal1[Calendar.DAY_OF_YEAR] == cal2[Calendar.DAY_OF_YEAR] &&
					cal1[Calendar.YEAR] == cal2[Calendar.YEAR]
			if (sameDay) {
				itemView.findViewById<TextView>(R.id.time_chat_tv).text = SimpleDateFormat.getTimeInstance(SimpleDateFormat.SHORT).format(chat.timestamp)
			} else {
				itemView.findViewById<TextView>(R.id.time_chat_tv).text = SimpleDateFormat.getDateTimeInstance(SimpleDateFormat.MEDIUM, SimpleDateFormat.SHORT).format(chat.timestamp)
			}
			if (chat.from != FirebaseAuth.getInstance().currentUser!!.uid) {
				usersViewModel.getUser(chat.from).observe(lifecycleOwner) {
					if (it != null) {
						Glide.with(context).load(it.profile_picture).into(itemView.findViewById(R.id.profile_icon_chat_left))
					} else {
						Log.e("TIMEBANKING", "The other user does not exist in database!")
					}
				}
			} else {
				if (chat.last_delivered) {
					itemView.findViewById<TextView>(R.id.is_delivered).visibility = VISIBLE
				} else {
					itemView.findViewById<TextView>(R.id.is_delivered).visibility = GONE
				}
			}
		}

		fun unbind() {

		}
	}

	private var chats = mutableListOf<Chat>()

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageItemHolder {
		val layout = when (viewType) {
			RIGHT_CHAT -> R.layout.chat_right
			LEFT_CHAT -> R.layout.chat_left
			else -> throw IllegalArgumentException("Invalid Type")
		}
		val item = LayoutInflater.from(parent.context).inflate(layout, parent, false)
		return MessageItemHolder(item)
	}

	override fun onBindViewHolder(holder: MessageItemHolder, position: Int) {
		holder.bind(chats[position], context, usersViewModel, fragment.viewLifecycleOwner)
	}

	override fun onViewRecycled(holder: MessageItemHolder) {
		holder.unbind()
	}

	override fun getItemViewType(position: Int): Int {
		return if (chats[position].from == FirebaseAuth.getInstance().currentUser!!.uid) RIGHT_CHAT else LEFT_CHAT
	}

	override fun getItemCount(): Int = chats.size

	companion object {
		private const val RIGHT_CHAT = 0
		private const val LEFT_CHAT = 1
	}

	fun setChatList(list: List<Chat>) {
		val chatsDiffCallback = ChatDiffCallback(chats, list)
		val chatsDiffResult = DiffUtil.calculateDiff(chatsDiffCallback)
		chats = list.toMutableList()
		chatsDiffResult.dispatchUpdatesTo(this)
	}
}

class ChatDiffCallback(private val oldList: List<Chat>, private val newList: List<Chat>): DiffUtil.Callback() {
	override fun getOldListSize(): Int = oldList.size

	override fun getNewListSize(): Int = newList.size

	override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition].from == newList[newItemPosition].from && oldList[oldItemPosition].timestamp == newList[newItemPosition].timestamp

	override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition] == newList[newItemPosition]
}
