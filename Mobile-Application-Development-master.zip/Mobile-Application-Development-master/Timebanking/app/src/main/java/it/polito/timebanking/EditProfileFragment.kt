package it.polito.timebanking

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.widget.*
import androidx.activity.addCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.children
import androidx.drawerlayout.widget.DrawerLayout
import androidx.drawerlayout.widget.DrawerLayout.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.MutableLiveData
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageView
import com.canhub.cropper.options
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import java.io.File
import java.io.FileOutputStream
import java.util.*
import kotlin.collections.ArrayList

class EditProfileFragment : Fragment(R.layout.edit_profile_fragment_layout),
    PopupMenu.OnMenuItemClickListener {
    private lateinit var _resultLauncher: ActivityResultLauncher<Intent>
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>
    private lateinit var cropImage: ActivityResultLauncher<CropImageContractOptions>
    private val userViewModel: UserViewModel by activityViewModels()
    private lateinit var topAppBar: MaterialToolbar
    private lateinit var profilePictureImageView: ImageView
    private lateinit var profilePictureImageButton: ImageButton
    private lateinit var fullnameInputLayout: TextInputLayout
    private lateinit var nicknameInputLayout: TextInputLayout
    private lateinit var emailInputLayout: TextInputLayout
    private lateinit var locationInputLayout: TextInputLayout
    private lateinit var skillsInputLayout: TextInputLayout
    private lateinit var skillsChipGroup: ChipGroup
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var fullnameTextWatcher: FormTextWatcher
    private lateinit var emailTextWatcher: FormTextWatcher
    private var originalFullName: String = ""
    private var originalNickname: String = ""
    private var originalEmail: String = ""
    private var originalLocation: String = ""
    private var originalSkills: MutableList<String> = mutableListOf()
    private var _profilePicture: Uri? = null
    private var _oldProfilePicture: Uri? = null
    private var originalProfilePicture: Uri? = null
    private var firstEdit: Boolean = false
    private lateinit var userAuth: FirebaseUser

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setNavDrawerEnabled(false)
        profilePictureImageView = view.findViewById(R.id.profile_picture_iv_edit_profile)
        profilePictureImageButton = view.findViewById(R.id.profile_picture_button_edit_profile)
        profilePictureImageButton.setOnClickListener {
            PopupMenu(activity as Context, it).apply {
                setOnMenuItemClickListener(this@EditProfileFragment)
                inflate(R.menu.change_picture)
                show()
            }
        }
        requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                if (isGranted) {
                    openGallery()
                } else {
                    sharedPreferences.edit().putInt(
                        "DONT_ASK_PERMISSION",
                        sharedPreferences.getInt("DONT_ASK_PERMISSION", 0) + 1
                    ).apply()
                    showPermissionDeniedDialog()
                }
            }
        cropImage = registerForActivityResult(CropImageContract()) { result ->
            if (result.isSuccessful) {
                @Suppress("DEPRECATION") val croppedPhoto: Bitmap? =
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        val source =
                            result.uriContent?.let {
                                ImageDecoder.createSource(
                                    requireActivity().contentResolver,
                                    it
                                )
                            }
                        source?.let { ImageDecoder.decodeBitmap(it) }
                    } else {
                        MediaStore.Images.Media.getBitmap(
                            requireActivity().contentResolver,
                            result.uriContent
                        )
                    }
                val fileName = createImageFile()
                val file = File(fileName?.path!!)
                val out = FileOutputStream(file)
                croppedPhoto!!.compress(Bitmap.CompressFormat.PNG, 100, out)

                _profilePicture = Uri.fromFile(file)

                renderImage()
            } else {
                //val exception = result.error
                //if (exception != null) {

                //Snackbar.make(view, exception.message as CharSequence, Snackbar.LENGTH_SHORT).show()
                //}
            }
        }
        _resultLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val data: Intent? = result.data
                    if (data != null && data.data != null) {
                        cropImage(data.data!!)
                    } else {
                        cropImage(_profilePicture!!)
                    }
                } else if (result.resultCode == Activity.RESULT_CANCELED) {
                    _profilePicture = _oldProfilePicture
                    renderImage()
                }

            }
        fullnameInputLayout = view.findViewById(R.id.fullname_input_layout)
        nicknameInputLayout = view.findViewById(R.id.nickname_input_layout)
        emailInputLayout = view.findViewById(R.id.email_input_layout)
        locationInputLayout = view.findViewById(R.id.location_input_layout)
        skillsInputLayout = view.findViewById(R.id.skills_input_layout)
        skillsChipGroup = view.findViewById(R.id.skills_chip_group_edit)
        sharedPreferences = requireActivity().getSharedPreferences(
            "user_preferences",
            MODE_PRIVATE
        ) as SharedPreferences
        userAuth = Firebase.auth.currentUser!!
        val user = userViewModel.getUser(userAuth.uid)
        user.observe(this.viewLifecycleOwner) { userDocument ->
            if (userDocument != null) {
                Log.d("TIMEBANKING", "User already exists")
                originalProfilePicture = Uri.parse(userDocument.profile_picture)
                originalFullName = userDocument.fullname
                originalNickname = userDocument.nickname
                originalEmail = userDocument.email
                originalLocation = userDocument.location
                if (savedInstanceState == null) {
                    if (_profilePicture == null) {
                        _profilePicture = originalProfilePicture
                        Glide.with(requireContext()).load(userDocument.profile_picture)
                            .into(profilePictureImageView)
                    } else {
                        Glide.with(requireContext()).load(_profilePicture)
                            .into(profilePictureImageView)
                    }
                    fullnameInputLayout.editText?.setText(originalFullName)
                    nicknameInputLayout.editText?.setText(originalNickname)
                    emailInputLayout.editText?.setText(originalEmail)
                    locationInputLayout.editText?.setText(originalLocation)

                }
                originalSkills = mutableListOf()
                if (savedInstanceState == null) skillsChipGroup.removeAllViews()
                if (userDocument.skills.isNotEmpty()) {
                    for (skill in userDocument.skills) {
                        originalSkills += skill
                        if (savedInstanceState == null) {
                            val chipToAdd = Chip(requireContext())
                            chipToAdd.text = skill
                            chipToAdd.isCloseIconVisible = true
                            chipToAdd.setOnCloseIconClickListener {
                                skillsChipGroup.removeView(chipToAdd)
                            }
                                skillsChipGroup.addView(chipToAdd)
                        }
                    }
                }
            } else {
                firstEdit = true
                Log.d("TIMEBANKING", "User does not exists")
                topAppBar = requireActivity().findViewById(R.id.topAppBar) as MaterialToolbar
                topAppBar.title = "Create profile"
                originalProfilePicture = userAuth.photoUrl
                renderImage()
                originalFullName = userAuth.displayName!!
                originalEmail = userAuth.email!!
                if (savedInstanceState == null) {
                    if (_profilePicture == null) {
                        _profilePicture = originalProfilePicture
                    }
                    fullnameInputLayout.editText?.setText(originalFullName)
                    emailInputLayout.editText?.setText(originalEmail)
                }
            }
        }
        val skillsTextWatcher = object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().isNotEmpty() && p0.endsWith('\n')) {
                        if (skillsInputLayout.editText?.text.toString().trim().isNotEmpty()) {
                            val skill = skillsInputLayout.editText?.text.toString().trim().lowercase(Locale.getDefault()).replaceFirstChar { it.titlecase(Locale.getDefault()) }
                            if(!getSkillList().contains(skill)) {
                                val chipToAdd = Chip(activity as Context)
                                chipToAdd.text = skill
                                chipToAdd.isCloseIconVisible = true
                                chipToAdd.setOnCloseIconClickListener {
                                    skillsChipGroup.removeView(chipToAdd)
                                }
                                skillsChipGroup.addView(chipToAdd)
                            } else {
                                Snackbar.make(
                                    requireView(),
                                    "Skill already entered",
                                    Snackbar.LENGTH_SHORT
                                ).show()
                            }
                        }
                        skillsInputLayout.editText?.setText("")
                    }
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
        }
        skillsInputLayout.editText?.addTextChangedListener(skillsTextWatcher)
        fullnameTextWatcher = FormTextWatcher(fullnameInputLayout)
        fullnameInputLayout.editText?.addTextChangedListener(fullnameTextWatcher)
        emailTextWatcher = FormTextWatcher(emailInputLayout)
        emailInputLayout.editText?.addTextChangedListener(emailTextWatcher)
        setHasOptionsMenu(true)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            backRoutine()
        }
    }

    private fun setNavDrawerEnabled(value: Boolean) {
        if (value)
            requireActivity().findViewById<DrawerLayout>(R.id.drawer_layout)
                .setDrawerLockMode(LOCK_MODE_UNLOCKED)
        else requireActivity().findViewById<DrawerLayout>(R.id.drawer_layout)
            .setDrawerLockMode(LOCK_MODE_LOCKED_CLOSED)
    }

    private fun cropImage(uri: Uri) {
        cropImage.launch(
            options(uri = uri) {
                setGuidelines(CropImageView.Guidelines.ON)
                setOutputCompressFormat(Bitmap.CompressFormat.PNG)
                setAspectRatio(1, 1)
                setFixAspectRatio(true)
                setCropShape(CropImageView.CropShape.OVAL)
            }
        )
    }

    private fun backRoutine() {
        if (firstEdit) {
            if (validateForm()) {
                save()
                setNavDrawerEnabled(true)
                findNavController().navigateUp()
            } else {
                Snackbar.make(
                    requireView(),
                    "You must create a compliant profile in order to proceed",
                    Snackbar.LENGTH_SHORT
                ).show()
            }
            return
        }
        val changedSomething = checkDiffs()
        if (changedSomething) {
            MaterialAlertDialogBuilder(activity as Context)
                .setTitle("Wait!")
                .setMessage("Do you want to save before leaving?")
                .setNeutralButton("Cancel") { dialog, _ ->
                    dialog.dismiss()
                }
                .setNegativeButton("No") { _, _ ->
                    setNavDrawerEnabled(true)
                    /*if (!sharedPreferences.contains("USER_EXIST")) {
                        findNavController().navigateUp()
                    }*/
                    findNavController().navigateUp()
                }
                .setPositiveButton("Yes") { _, _ ->
                    if (validateForm()) {
                        save()
                        setNavDrawerEnabled(true)
                        findNavController().navigateUp()
                    } else {
                        Snackbar.make(
                            view as View,
                            "Make sure to correct all the errors in the form",
                            Snackbar.LENGTH_LONG
                        ).show()
                    }
                }
                .show()
        } else {
            setNavDrawerEnabled(true)
            /*if(!sharedPreferences.contains("USER_EXIST")) {
                findNavController().navigateUp()
            }*/
            findNavController().navigateUp()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("profilePicture", _profilePicture.toString())
        outState.putString("fullname", fullnameInputLayout.editText?.text.toString())
        outState.putString("nickname", nicknameInputLayout.editText?.text.toString())
        outState.putString("email", emailInputLayout.editText?.text.toString())
        outState.putString("location", locationInputLayout.editText?.text.toString())
        val skills: MutableList<String> = mutableListOf()
        for (i in 0 until skillsChipGroup.childCount) {
            val chip: Chip = skillsChipGroup.getChildAt(i) as Chip
            skills += chip.text.toString().trim()
        }
        outState.putStringArrayList("skills", ArrayList(skills))
    }

    fun getSkillList() : MutableList<String>{
        val skills: MutableList<String> = mutableListOf()
        for (i in 0 until skillsChipGroup.childCount) {
            val chip: Chip = skillsChipGroup.getChildAt(i) as Chip
            skills += chip.text.toString().trim()
        }
        return skills
    }

    override fun onViewStateRestored(savedInstanceState: Bundle?) {
        super.onViewStateRestored(savedInstanceState)
        if (savedInstanceState != null) {
            _profilePicture = Uri.parse(savedInstanceState.getString("profilePicture", ""))
            fullnameInputLayout.editText?.setText(savedInstanceState.getString("fullname", ""))
            nicknameInputLayout.editText?.setText(savedInstanceState.getString("nickname", ""))
            emailInputLayout.editText?.setText(savedInstanceState.getString("email", ""))
            locationInputLayout.editText?.setText(savedInstanceState.getString("location", ""))
            skillsChipGroup.removeAllViews()
            val skills = savedInstanceState.getStringArrayList("skills")?.toMutableList()
            if (skills != null && skills.isNotEmpty()) {
                for (skill in skills) {
                    originalSkills += skill
                    val chipToAdd = Chip(requireContext())
                    chipToAdd.text = skill
                    chipToAdd.isCloseIconVisible = true
                    chipToAdd.setOnCloseIconClickListener {
                        skillsChipGroup.removeView(chipToAdd)
                    }
                    skillsChipGroup.addView(chipToAdd)
                }
            }
            renderImage()
        }
    }

    private fun createImageFile(): Uri? {
        val storageDir: File? =
            requireActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return Uri.fromFile(
            File.createTempFile(
                "JPEG_PROFILE_PICTURE_TIMEBANKING_", /* prefix */
                ".jpg", /* suffix */
                storageDir /* directory */
            )
        )
    }

    private fun renderImage() {
        if (_profilePicture != null) {
            Glide.with(requireContext()).load(_profilePicture).into(profilePictureImageView)
        } else {
            if (originalProfilePicture == null) {
                profilePictureImageView.setImageResource(R.drawable.ic_baseline_account_circle_24)
            } else {
                Glide.with(requireContext()).load(originalProfilePicture)
                    .into(profilePictureImageView)
            }
        }
    }

    private fun takePicture() {
        _oldProfilePicture = _profilePicture
        _profilePicture = createImageFile()
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "it.polito.fileprovider",
            File(_profilePicture?.path!!)
        )
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        _resultLauncher.launch(intent)
    }

    private fun checkDiffs(): Boolean =
        _profilePicture != originalProfilePicture ||
                fullnameInputLayout.editText?.text.toString() != originalFullName ||
                nicknameInputLayout.editText?.text.toString() != originalNickname ||
                emailInputLayout.editText?.text.toString() != originalEmail ||
                locationInputLayout.editText?.text.toString() != originalLocation ||
                skillsChipGroup.children.map { (it as Chip).text.toString().trim() }
                    .toMutableList() != originalSkills

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.save_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                backRoutine()
                true
            }
            R.id.save_menu_item -> {
                if (validateForm()) {
                    save()
                    setNavDrawerEnabled(true)
                    findNavController().navigateUp()
                } else {
                    Snackbar.make(
                        view as View,
                        "Make sure to correct all the errors in the form",
                        Snackbar.LENGTH_LONG
                    ).show()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun save() {
        val fullname: String = fullnameInputLayout.editText?.text.toString().trim()
        val nickname: String = nicknameInputLayout.editText?.text.toString().trim()
        val email: String = emailInputLayout.editText?.text.toString().trim()
        val location: String = locationInputLayout.editText?.text.toString().trim()
        val skills: MutableList<String> = mutableListOf()
        for (i in 0 until skillsChipGroup.childCount) {
            val chip: Chip = skillsChipGroup.getChildAt(i) as Chip
            skills += chip.text.toString().trim()
        }
        val user: User = if (_profilePicture != originalProfilePicture) {
            User(
                fullname = fullname,
                nickname = nickname,
                email = email,
                location = location,
                skills = skills
            )
        } else {
            User(
                profile_picture = _profilePicture.toString(),
                fullname = fullname,
                nickname = nickname,
                email = email,
                location = location,
                skills = skills
            )
        }
        val result: MutableLiveData<Boolean> = if (_profilePicture != originalProfilePicture)
            userViewModel.setUser(userAuth.uid, user, _profilePicture)
        else {
            userViewModel.setUser(userAuth.uid, user, null)
        }
        result.observe(this.viewLifecycleOwner) {
            if (it) {
                Snackbar.make(requireView(), "User successfully updated", Snackbar.LENGTH_SHORT)
                    .show()
            } else {
                Snackbar.make(requireView(), "User update failed", Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun validateForm(): Boolean = fullnameTextWatcher.check() &&
            emailTextWatcher.check()

    override fun onMenuItemClick(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.select_from_gallery -> {
                when {
                    ContextCompat.checkSelfPermission(
                        requireContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED -> {
                        openGallery()
                    }
                    shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE) -> {
                        MaterialAlertDialogBuilder(requireContext()).setTitle("Memory permissions")
                            .setMessage("Please grant memory access permission to use this functionality")
                            .setNegativeButton("No thanks", null)
                            .setPositiveButton("Ok") { _, _ ->
                                requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                            }
                            .show()
                    }
                    else -> {
                        requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                }
                true
            }
            R.id.use_camera -> {
                takePicture()
                true
            }
            else -> false
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        _resultLauncher.launch(intent)
    }

    private fun showPermissionDeniedDialog() {
        if (sharedPreferences.getInt("DONT_ASK_PERMISSION", 0) < 2) {
            MaterialAlertDialogBuilder(activity as Context).setTitle("Permission Denied")
                .setMessage("To use this functionality, memory access permission is required. Do you want to grant it?")
                .setPositiveButton(
                    "Ok"
                ) { _, _ ->
                    requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                .setNegativeButton("No", null)
                .show()
        } else {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Permission Denied")
                .setMessage("Permission is denied, please allow permissions from App Settings.")
                .setPositiveButton(
                    "App Settings"
                ) { _, _ ->
                    val intent = Intent()
                    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                    val uri = Uri.fromParts("package", requireContext().packageName, null)
                    intent.data = uri
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}

class FormTextWatcher(_view: TextInputLayout) : TextWatcher {
    private val view: TextInputLayout = _view

    fun check(): Boolean {
        when (view.id) {
            R.id.fullname_input_layout -> {
                return if (view.editText?.text == null || view.editText?.text.toString()
                        .isEmpty()
                ) {
                    view.error = "Full name must not be empty"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
            R.id.email_input_layout -> {
                return if (view.editText?.text == null || view.editText?.text.toString()
                        .isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(view.editText?.text.toString())
                        .matches()
                ) {
                    view.error = "Email must be not empty and a valid email address"
                    view.isErrorEnabled = true
                    false
                } else {
                    view.error = ""
                    view.isErrorEnabled = false
                    true
                }
            }
        }
        return false
    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }

    override fun afterTextChanged(p0: Editable?) {
        check()
    }

}