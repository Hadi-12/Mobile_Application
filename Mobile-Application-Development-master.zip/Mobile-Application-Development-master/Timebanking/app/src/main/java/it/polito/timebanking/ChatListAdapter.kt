package it.polito.timebanking
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.LifecycleOwner
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import de.hdodenhof.circleimageview.CircleImageView

class ChatListAdapter(val fragment: ChatListFragment, private val usersViewModel: UserViewModel, val context: Context, private val timeslotsViewModel: TimeSlotViewModel) : RecyclerView.Adapter<ChatListAdapter.ChatItemHolder>() {
	class ChatItemHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
		private val otherUserName: TextView = itemView.findViewById(R.id.name_chat_item_tv)
		private val profileImage: CircleImageView = itemView.findViewById(R.id.profile_image)
		private val onlineStatus: CircleImageView = itemView.findViewById(R.id.online_status)
		private val lastMessage: TextView = itemView.findViewById(R.id.last_message_tv)
		private val timeslotReferred: TextView = itemView.findViewById(R.id.timeslot_referred_tv)

		fun bind(conversation: Conversation, usersViewModel: UserViewModel, lifecycleOwner: LifecycleOwner, context: Context, action: (v: View) -> Unit, timeslotsViewModel: TimeSlotViewModel) {
			usersViewModel.getUser(
				if (FirebaseAuth.getInstance().currentUser!!.uid == conversation.user1)
					conversation.user2
				else conversation.user1
			).observe(lifecycleOwner) {
				if (it != null) {
					Glide.with(context).load(it.profile_picture).into(profileImage)
					otherUserName.text = it.fullname
					onlineStatus.visibility = if (it.status == "online") VISIBLE else GONE
					lastMessage.text = if (conversation.chats.first().text != null) {
						conversation.chats.first().text
					} else if (conversation.chats.first().attachment != null) {
						"Picture"
					} else {
						"Message"
					}
					timeslotsViewModel.getTimeSlot(conversation.timeslot_referred).observe(lifecycleOwner) { timeslot_referred ->
						if (timeslot_referred != null) {
							timeslotReferred.text = timeslot_referred.title
							itemView.setOnClickListener(action)
						}
						else {
							Log.e("TIMEBANKING", "The timeslot referred could not be found")
						}
					}
				} else {
					Log.e("TIMEBANKING", "The other user does not exist in database!")
				}
			}
		}

		fun unbind() {

		}
	}

	private var conversations = mutableListOf<Conversation>()


	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatItemHolder {
		val item = LayoutInflater.from(parent.context).inflate(R.layout.chat_list_item, parent, false)
		return ChatItemHolder(item)
	}

	override fun onBindViewHolder(holder: ChatItemHolder, position: Int) {
		holder.bind(conversations[position], usersViewModel, fragment.viewLifecycleOwner, context, action = {
			fragment.navigateToChatFragment(conversations[position].id)
		}, timeslotsViewModel)
	}

	override fun onViewRecycled(holder: ChatItemHolder) {
		holder.unbind()
	}

	fun setConversationList(list: List<Conversation>) {
		val conversationsDiffCallback = ConversationsDiffCallback(conversations, list)
		val conversationsDiffResult = DiffUtil.calculateDiff(conversationsDiffCallback)
		conversations = list.toMutableList()
		conversationsDiffResult.dispatchUpdatesTo(this)
	}

	override fun getItemCount(): Int = conversations.size
}

class ConversationsDiffCallback(private val oldList: List<Conversation>, private val newList: List<Conversation>): DiffUtil.Callback() {
	override fun getOldListSize(): Int = oldList.size

	override fun getNewListSize(): Int = newList.size

	override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition].id == newList[newItemPosition].id

	override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition] == newList[newItemPosition]
}
