package it.polito.timebanking
import android.os.Bundle
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class ChatListFragment : Fragment(R.layout.chat_list_fragment_layout) {
    private lateinit var noMessagesTextView: TextView
    private lateinit var recyclerView: RecyclerView
    private val userViewModel: UserViewModel by activityViewModels()
    private val conversationsViewModel: ConversationViewModel by activityViewModels()
    private val timeSlotsViewModel by activityViewModels<TimeSlotViewModel> {
        TimeSlotViewModelFactory(requireActivity().application, "All")
    }
    private lateinit var adapterChatList: ChatListAdapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        noMessagesTextView=view.findViewById(R.id.no_messages_tv)
        recyclerView = view.findViewById(R.id.chat_list_recycle_view)
        adapterChatList = ChatListAdapter(this, userViewModel, requireContext(), timeSlotsViewModel)
        recyclerView.adapter = adapterChatList
        conversationsViewModel.getUserConversations(FirebaseAuth.getInstance().currentUser!!.uid).observe(this.viewLifecycleOwner) {
            if (it != null) {
                adapterChatList.setConversationList(it)
                if (it.isEmpty()) {
                    noMessagesTextView.visibility = VISIBLE
                } else {
                    noMessagesTextView.visibility = GONE
                }
            }
        }
    }
    fun navigateToChatFragment(conversationID: String) {
        findNavController().navigate(ChatListFragmentDirections.actionChatListFragmentToChatFragment(conversationID))
    }
}
