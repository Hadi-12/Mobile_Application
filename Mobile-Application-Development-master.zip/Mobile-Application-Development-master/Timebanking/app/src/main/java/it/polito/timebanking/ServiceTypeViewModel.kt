package it.polito.timebanking

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase

class ServiceTypeViewModel: ViewModel() {
    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    fun getOrderedByName(): LiveData<List<String>> {
        val result = MutableLiveData<List<String>>()
        db.collection("users").get().addOnSuccessListener { res ->
            val listBuilder = mutableListOf<String>()
            val listOfLists = res.mapNotNull { u -> u.get("skills") as List<*> }
            for (el in listOfLists) {
                for (el1 in el) {
                    listBuilder += el1 as String
                }
            }
            result.postValue(listBuilder.distinct().sorted())
        }
        return result
    }

    fun getMySkillsFirst(userVM: UserViewModel, lifecycleOwner: LifecycleOwner) : LiveData<List<String>> {
        val result = MutableLiveData<List<String>>()
        userVM.getUser(Firebase.auth.currentUser!!.uid).observe(lifecycleOwner) {
            db.collection("users").get().addOnSuccessListener { res ->
                val listBuilder = mutableListOf<String>()
                val listOfLists = res.mapNotNull { u -> u.get("skills") as List<*> }
                for (el in listOfLists) {
                    for (el1 in el) {
                        listBuilder += el1 as String
                    }
                }
                val mutableList = it!!.skills.toMutableList().distinct().sorted().toMutableList()
                mutableList += listBuilder.filter { u -> !it.skills.contains(u) }.distinct().sorted()
                result.postValue(mutableList)
            }
        }
        return result
    }
}