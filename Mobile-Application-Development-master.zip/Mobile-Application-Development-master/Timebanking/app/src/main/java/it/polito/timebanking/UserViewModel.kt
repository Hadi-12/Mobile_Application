package it.polito.timebanking

import android.net.Uri
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import java.lang.Exception

class UserViewModel: ViewModel() {

    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()
    private var storage: FirebaseStorage = Firebase.storage

    fun getUser(uid: String): LiveData<User?> {
        val userMutableLiveData = MutableLiveData<User?>()
        if (uid != "") {
            db.collection("users").document(uid).addSnapshotListener { documentSnapshot, error ->
                if (error != null) {
                    Log.e(
                        "TIMEBANKING",
                        "GET USER Snapshot Listener failed: ${error.localizedMessage}"
                    )
                    userMutableLiveData.postValue(null)
                    return@addSnapshotListener
                }
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    val user = documentSnapshot.toUser(uid)
                    userMutableLiveData.postValue(user)
                } else {
                    Log.e("TIMEBANKING", "GET USER user doesn't exist")
                    userMutableLiveData.postValue(null)
                }
            }
        }
        return userMutableLiveData
    }

    fun setUserStatus(uid: String, status: String): MutableLiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        db.collection("users").document(uid).update("status", status).addOnCompleteListener {
            if (it.isSuccessful) {
                result.postValue(true)
            } else {
                Log.e("TIMEBANKING", "SET USER STATUS Couldn't set user status to: $status")
                result.postValue(false)
            }
        }
        return result
    }

    fun creditExchange(credit: Duration, debtorID: String, creditorID: String): LiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        db.collection("users").document(debtorID).get().addOnCompleteListener { resultDebtor ->
            if (resultDebtor.isSuccessful) {
                val debtor = resultDebtor.result.toUser(debtorID)
                if (debtor != null) {
                    val debtorOldCredit = debtor.credit
                    db.collection("users").document(creditorID).get().addOnCompleteListener { resultCreditor ->
                        if (resultCreditor.isSuccessful) {
                            val creditor = resultCreditor.result.toUser(creditorID)
                            if (creditor != null) {
                                val creditorOldCredit = creditor.credit
                                val debtorNewCredit = debtorOldCredit.minus(credit)
                                db.collection("users").document(debtorID).update("credit", debtorNewCredit).addOnCompleteListener { addDebtorCreditResult ->
                                    if (addDebtorCreditResult.isSuccessful) {
                                        val creditorNewCredit = creditorOldCredit.plus(credit)
                                        db.collection("users").document(creditorID).update("credit", creditorNewCredit).addOnCompleteListener { addCreditorCreditResult ->
                                            if (addCreditorCreditResult.isSuccessful) {
                                                result.postValue(true)
                                            } else {
                                                Log.e("TIMEBANKING", "CREDIT EXCHANGE Could not update creditor credit")
                                                result.postValue(false)
                                            }
                                        }
                                    } else {
                                        Log.e("TIMEBANKING", "CREDIT EXCHANGE Could not update debtor credit")
                                        result.postValue(false)
                                    }
                                }
                            } else {
                                Log.e("TIMEBANKING", "CREDIT EXCHANGE Could not parse creditor")
                                result.postValue(false)
                            }
                        } else {
                            Log.e("TIMEBANKING", "CREDIT EXCHANGE Could not retrieve creditor")
                            result.postValue(false)
                        }
                    }
                } else {
                    Log.e("TIMEBANKING", "CREDIT EXCHANGE Could not parse debtor")
                    result.postValue(false)
                }
            } else {
                Log.e("TIMEBANKING", "CREDIT EXCHANGE Could not retrieve debtor")
                result.postValue(false)
            }
        }
        return result
    }

    fun setUser(uid: String, user: User, profilePicture: Uri?): MutableLiveData<Boolean> {
        val result: MutableLiveData<Boolean> = MutableLiveData<Boolean>()
        if (profilePicture != null) {
            val imageRef =
                storage.reference.child("users/profile_pictures/${uid}/${profilePicture.lastPathSegment}")
            imageRef
                .putFile(profilePicture).addOnSuccessListener {
                    Log.d("TIMEBANKING", "Profile picture loaded into storage")
                    imageRef.downloadUrl.addOnSuccessListener { uri ->
                        user.profile_picture = uri.toString()
                        db.collection("users").document(uid).set(user).addOnSuccessListener {
                            Log.d("TIMEBANKING", "User set/updated!")
                            result.postValue(true)
                        }.addOnFailureListener {
                            Log.e(
                                "TIMEBANKING",
                                "Error setting/updating user: ${it.localizedMessage}"
                            )
                            result.postValue(false)
                        }
                    }.addOnFailureListener {
                        Log.e(
                            "TIMEBANKING",
                            "Error inserting profile picture reference into profile: ${it.localizedMessage}"
                        )
                        result.postValue(false)
                    }
                }.addOnFailureListener {
                    Log.e(
                        "TIMEBANKING",
                        "Error uploading profile picture to storage: ${it.localizedMessage}"
                    )
                    result.postValue(false)
                }
        } else {
            db.collection("users").document(uid).set(user).addOnSuccessListener {
                Log.d("TIMEBANKING", "User set/updated!")
                result.postValue(true)
            }.addOnFailureListener {
                Log.e("TIMEBANKING", "Error setting/updating user: ${it.localizedMessage}")
                result.postValue(false)
            }
        }
        return result
    }


}

private operator fun Int?.plus(credit: Duration): Int? {
    return this?.plus(((credit.hours*60) + credit.minutes))
}

data class User(
    var profile_picture: String = "",
    val fullname: String = "",
    val nickname: String = "",
    val email: String = "",
    val location: String = "",
    val skills: List<String> = emptyList(),
    var status:String = "",
    var credit:Int = 30,

    @get:Exclude
    var id: String = ""

)

fun DocumentSnapshot.toUser(id: String): User? {
    return try {
        val profilePicture = get("profile_picture") as String
        val fullname = get("fullname") as String
        val nickname = get("nickname") as String
        val email = get("email") as String
        val location = get("location") as String
        val skills = (get("skills") as List<*>).filterIsInstance<String>()
        val status = get("status") as String
        val credit = (get("credit") as Long).toInt()
        User(
            profile_picture = profilePicture,
            fullname = fullname,
            nickname = nickname,
            email = email,
            location = location,
            skills = skills,
            status = status,
            id = id,
            credit = credit
        )
    } catch (e: Exception) {
        Log.e("TIMEBANKING", "TO_USER: ${e.localizedMessage!!}")
        null
    }
}