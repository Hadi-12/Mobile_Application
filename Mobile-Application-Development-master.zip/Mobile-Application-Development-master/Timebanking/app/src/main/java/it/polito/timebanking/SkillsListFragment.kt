package it.polito.timebanking

import android.os.Bundle
import android.view.*
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.*
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase


class SkillsListFragment: Fragment(R.layout.skills_list_fragment_layout) {
    private val serviceTypesViewModel by viewModels<ServiceTypeViewModel>()
    private val userViewModel by viewModels<UserViewModel>()
    private lateinit var adapter: SkillAdapter
    private lateinit var userSkills : List<String>
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = SkillAdapter(this)
        recyclerView.adapter = adapter
        userViewModel.getUser(Firebase.auth.currentUser!!.uid).observe(this.viewLifecycleOwner) { user ->
            if(user != null)
            userSkills = user.skills
        }
        val orderBySpinner = view.findViewById<Spinner>(R.id.order_by_spinner_skills)
        ArrayAdapter.createFromResource(requireContext(), R.array.order_by_choices_skills, R.layout.simple_item_choice_item)
            .also { orderByAdapter ->
                orderByAdapter.setDropDownViewResource(R.layout.simple_item_choice_item)
                orderBySpinner.adapter = orderByAdapter
            }
        val noSkillsLayout = view.findViewById<RelativeLayout>(R.id.no_skills_list_layout)
        val editProfileButton = view.findViewById<Button>(R.id.no_skills_list_edit_profile_button)
        editProfileButton.setOnClickListener {
            findNavController().navigate(SkillsListFragmentDirections.actionSkillsListFragmentToEditProfileFragment())
        }
        val orderByLayout = view.findViewById<LinearLayout>(R.id.order_by_layout_skills)
        orderBySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(av: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                when (av?.getItemAtPosition(pos).toString()) {
                    resources.getStringArray(R.array.order_by_choices_skills)[0] -> {
                        serviceTypesViewModel.getOrderedByName().observe(requireParentFragment().viewLifecycleOwner) {
                            if (it.isNotEmpty()) {
                                adapter.setServiceTypesList(it)
                                noSkillsLayout.visibility = GONE
                                orderByLayout.visibility = VISIBLE
                            }
                            else {
                                orderByLayout.visibility = GONE
                                noSkillsLayout.visibility = VISIBLE
                            }
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_skills)[1] -> {
                        serviceTypesViewModel.getMySkillsFirst(userViewModel, requireParentFragment().viewLifecycleOwner).observe(requireParentFragment().viewLifecycleOwner) {
                            adapter.setServiceTypesList(it)
                        }
                    }
                }
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }
        setHasOptionsMenu(true)
    }
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.search_menu, menu)
        val searchItem: MenuItem = menu.findItem(R.id.actionSearch)
        // getting search view of our item.
        val searchView = searchItem.actionView as SearchView
        val searchEditText =
            searchView.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)
        requireContext().let {
            searchEditText.setTextColor( ContextCompat.getColor(it, R.color.white))
            searchEditText.setHintTextColor(ContextCompat.getColor(it, R.color.white))
        }

        // below line is to call set on query text listener method.
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
         override fun onQueryTextChange(newText: String?): Boolean {
             if (newText != null) {
                 serviceTypesViewModel.getOrderedByName()
                     .observe(requireParentFragment().viewLifecycleOwner) {
                         adapter.setServiceTypesList(it)
                         adapter.addFilter(newText)
                     }
             }
                 else{
                     serviceTypesViewModel.getOrderedByName().observe(requireParentFragment().viewLifecycleOwner) {
                         adapter.setServiceTypesList(it)

                     }
                 }

                return false
            }
        })

    }
    fun openServiceTypeFragment(serviceType: String) = findNavController().navigate(SkillsListFragmentDirections.actionSkillsListFragmentToTimeSlotListFragment(serviceType))
}

class SkillAdapter(val fragment: SkillsListFragment): RecyclerView.Adapter<SkillAdapter.SkillHolder>() {

    class SkillHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val label: TextView = itemView.findViewById(R.id.service_name_tv)

        fun bind(serviceType: String, action: (v: View)->Unit) {
            label.text = serviceType
            itemView.setOnClickListener(action)
        }

        fun unbind() {
            itemView.setOnClickListener(null)
        }
    }
    private var serviceTypes: List<String> = listOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SkillHolder {
        val item = LayoutInflater.from(parent.context).inflate(R.layout.service_item, parent, false)
        return SkillHolder(item)
    }

    override fun onBindViewHolder(holder: SkillHolder, position: Int) {
        holder.bind(serviceTypes[position], action = {
            fragment.openServiceTypeFragment(serviceTypes[position])
        })
    }

    override fun onViewRecycled(holder: SkillHolder) {
        holder.unbind()
    }

    fun setServiceTypesList(list: List<String>) {
        val serviceTypesDiffCallback = ServiceTypesDiffCallback(serviceTypes, list)
        val serviceTypesDiffResult = DiffUtil.calculateDiff(serviceTypesDiffCallback)
        serviceTypes = list
        serviceTypesDiffResult.dispatchUpdatesTo(this)
    }

    override fun getItemCount(): Int = serviceTypes.size

    fun addFilter(text : String) {
        val newData = serviceTypes.filter{ it.contains(text,ignoreCase = true) }
        setServiceTypesList(newData)
    }
}
class ServiceTypesDiffCallback(private val oldList: List<String>, private val newList: List<String>): DiffUtil.Callback() {
    override fun getOldListSize(): Int = oldList.size

    override fun getNewListSize(): Int = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldList[oldItemPosition] == newList[newItemPosition]
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        val oldElement = oldList[oldItemPosition]
        val newElement = newList[newItemPosition]
        return oldElement === newElement
    }
}