package it.polito.timebanking

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupWithNavController
import com.bumptech.glide.Glide
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.navigation.NavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {


    private val userViewModel: UserViewModel by viewModels()
    private lateinit var navigationView: NavigationView
    private lateinit var topAppBar: MaterialToolbar
    private lateinit var navController: NavController
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var drawerLayout: DrawerLayout

    private var user: FirebaseUser? = FirebaseAuth.getInstance().currentUser


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.navigationBarColor = ContextCompat.getColor(this, com.google.android.material.R.color.design_default_color_primary)
        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.navigation_view)
        topAppBar = findViewById(R.id.topAppBar)
        navController =
            (supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as NavHostFragment).navController
        appBarConfiguration = AppBarConfiguration(navController.graph, drawerLayout)
        topAppBar.setupWithNavController(navController, appBarConfiguration)
        navigationView.setupWithNavController(navController)
        setSupportActionBar(topAppBar)
        val headerView: View = navigationView.getHeaderView(0)
        if(user != null) {
            navigationView.menu.findItem(R.id.logout).isVisible = true
            navigationView.menu.findItem(R.id.logout).setOnMenuItemClickListener {
                if(it.itemId == R.id.logout) {
                    if (user != null) userViewModel.setUserStatus(user!!.uid, "offline")
                    Firebase.auth.signOut()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
                true
            }
            val userStored = userViewModel.getUser(user!!.uid)
            userStored.observe(this) {
                Log.d("TIMEBANKING", "User signed in")
                headerView.findViewById<TextView>(R.id.profile_fullname_tv_nav_drawer)?.text = it?.fullname
                Glide.with(this).load(it?.profile_picture).into(headerView.findViewById(R.id.profile_picture_icon_nav_drawer))
            }
            if(savedInstanceState == null) {
                val isNewUser = intent.getBooleanExtra("NEW_USER", false)
                if (isNewUser) {
                    Snackbar.make(
                        topAppBar,
                        "Welcome, ${user?.displayName}! Please complete your profile",
                        Snackbar.LENGTH_SHORT
                    ).show()
                    navController.navigate(R.id.editProfileFragment)
                } else {
                    Snackbar.make(
                        topAppBar,
                        "Welcome back, ${user?.displayName}!",
                        Snackbar.LENGTH_SHORT
                    ).show()
                }
            }
        }
        else {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    override fun onStart() {
        if (user != null) userViewModel.setUserStatus(user!!.uid, "online")
        super.onStart()
    }

    override fun onPause() {
        if (user != null) userViewModel.setUserStatus(user!!.uid, "offline")
        super.onPause()
    }

    override fun onDestroy() {
        if (user != null) userViewModel.setUserStatus(user!!.uid, "offline")
        super.onDestroy()
    }
}