package it.polito.timebanking

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bumptech.glide.Glide
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.firestore.Query
import de.hdodenhof.circleimageview.CircleImageView
import java.text.SimpleDateFormat

class RatingListFragment: Fragment(R.layout.rating_list_fragment) {
    private val args: RatingListFragmentArgs by navArgs()
    private lateinit var ratingsAdapter: RatingAdapter
    private val usersViewModel by viewModels<UserViewModel>()
    private val ratingViewModel by viewModels<RatingViewModel>()
    private lateinit var topAppBar: MaterialToolbar

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        topAppBar = requireActivity().findViewById(R.id.topAppBar) as MaterialToolbar
        val noRatingsTV = view.findViewById<TextView>(R.id.no_ratings_tv)
        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
        val linearLayoutManager = LinearLayoutManager(requireContext())
        recyclerView.layoutManager = linearLayoutManager
        ratingsAdapter = RatingAdapter(this)
        recyclerView.adapter = ratingsAdapter
        usersViewModel.getUser(args.userId).observe(viewLifecycleOwner) {
            if (it != null) {
                topAppBar.title = it.fullname + " Ratings"
            } else {
                Snackbar.make(requireView(), "Couldn't retrieve user from database", Snackbar.LENGTH_SHORT).show()
            }
        }
        val orderBySpinner = view.findViewById<Spinner>(R.id.order_by_spinner_ratings)
        ArrayAdapter.createFromResource(requireContext(), R.array.order_by_choices_ratings, R.layout.simple_item_choice_item)
            .also { orderByAdapter ->
                orderByAdapter.setDropDownViewResource(R.layout.simple_item_choice_item)
                orderBySpinner.adapter = orderByAdapter
            }
        val orderByLayout = view.findViewById<LinearLayout>(R.id.order_by_layout_ratings)
        orderBySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(av: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                when (av?.getItemAtPosition(pos).toString()) {
                    resources.getStringArray(R.array.order_by_choices_ratings)[0] -> {
                        ratingViewModel.getRatingsForUser(args.userId, "date", Query.Direction.ASCENDING).observe(viewLifecycleOwner) { list ->
                            if (list != null) {
                                ratingsAdapter.setRatingsList(list.mapNotNull { e -> e!!.first }, list.mapNotNull { e -> e!!.second.first }, list.mapNotNull { e -> e!!.second.second})
                                if (list.isEmpty()) {
                                    noRatingsTV.visibility = VISIBLE
                                    orderByLayout.visibility = GONE
                                } else {
                                    noRatingsTV.visibility = GONE
                                    orderByLayout.visibility = VISIBLE
                                }
                                val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                recyclerView.scrollToPosition(position)
                            } else {
                                Snackbar.make(requireView(), "Couldn't retrieve user ratings from database", Snackbar.LENGTH_SHORT).show()
                            }
                        }
                    }
                    resources.getStringArray(R.array.order_by_choices_ratings)[1] -> {
                        ratingViewModel.getRatingsForUser(args.userId, "numStars", Query.Direction.DESCENDING).observe(viewLifecycleOwner) { list ->
                            if (list != null) {
                                ratingsAdapter.setRatingsList(list.mapNotNull { e -> e!!.first }, list.mapNotNull { e -> e!!.second.first }, list.mapNotNull { e -> e!!.second.second})
                                if (list.isEmpty()) {
                                    noRatingsTV.visibility = VISIBLE
                                    orderByLayout.visibility = GONE
                                } else {
                                    noRatingsTV.visibility = GONE
                                    orderByLayout.visibility = VISIBLE
                                }
                                val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                                recyclerView.scrollToPosition(position)
                            } else {
                                Snackbar.make(requireView(), "Couldn't retrieve user ratings from database", Snackbar.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }
        val refreshLayout = view.findViewById<SwipeRefreshLayout>(R.id.refresh_layout)
        refreshLayout.setOnRefreshListener {
            when (orderBySpinner.selectedItem) {
                resources.getStringArray(R.array.order_by_choices_ratings)[0] -> {
                    ratingViewModel.getRatingsForUser(args.userId, "date", Query.Direction.ASCENDING).observe(viewLifecycleOwner) { list ->
                        if (list != null) {
                            ratingsAdapter.setRatingsList(list.mapNotNull { e -> e!!.first }, list.mapNotNull { e -> e!!.second.first }, list.mapNotNull { e -> e!!.second.second})
                            if (list.isEmpty()) {
                                noRatingsTV.visibility = VISIBLE
                                orderByLayout.visibility = GONE
                            } else {
                                noRatingsTV.visibility = GONE
                                orderByLayout.visibility = VISIBLE
                            }
                            refreshLayout.isRefreshing = false
                            val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        } else {
                            Snackbar.make(requireView(), "Couldn't retrieve user ratings from database", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                }
                resources.getStringArray(R.array.order_by_choices_ratings)[1] -> {
                    ratingViewModel.getRatingsForUser(args.userId, "numStars", Query.Direction.DESCENDING).observe(viewLifecycleOwner) { list ->
                        if (list != null) {
                            ratingsAdapter.setRatingsList(list.mapNotNull { e -> e!!.first }, list.mapNotNull { e -> e!!.second.first }, list.mapNotNull { e -> e!!.second.second})
                            if (list.isEmpty()) {
                                noRatingsTV.visibility = VISIBLE
                                orderByLayout.visibility = GONE
                            } else {
                                noRatingsTV.visibility = GONE
                                orderByLayout.visibility = VISIBLE
                            }
                            refreshLayout.isRefreshing = false
                            val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                            recyclerView.scrollToPosition(position)
                        } else {
                            Snackbar.make(requireView(), "Couldn't retrieve user ratings from database", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    fun openTimeslotDetailFragment(timeslotID: String) = findNavController().navigate(RatingListFragmentDirections.actionRatingListFragmentToTimeSlotDetailsFragment(timeslotID, "All"))
}

class RatingAdapter(val fragment: RatingListFragment): RecyclerView.Adapter<RatingAdapter.RatingHolder>() {
    class RatingHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
        private val ratingUser: TextView = itemView.findViewById(R.id.rating_user_tv)
        private val ratingUserRole: TextView = itemView.findViewById(R.id.rating_user_role_tv)
        private val ratingUserProfileImage: CircleImageView = itemView.findViewById(R.id.profile_image)
        private val ratingBar: RatingBar = itemView.findViewById(R.id.rating_bar)
        private val timeslotReferred: TextView = itemView.findViewById(R.id.timeslot_referred_rating_tv)
        private val ratingDate: TextView = itemView.findViewById(R.id.rating_date_tv)
        private val comment: TextView = itemView.findViewById(R.id.comment_rating_tv)
        private val title: TextView = itemView.findViewById(R.id.title_rating_tv)

        private fun comment(string: String): String {
            return "\"" + string + "\""
        }

        fun bind(rating:Rate, ratingUserName: String, timeslotReferredTitle: String, action: (v: View)->Unit, role: String, profileImage: String, context: Context) {
            ratingUser.text = ratingUserName
            ratingUserRole.text = context.getString(R.string.role_with_param_and_parenthesis, role)
            Glide.with(context).load(profileImage).into(ratingUserProfileImage)
            ratingBar.rating = rating.numStars.toFloat()
            timeslotReferred.text = timeslotReferredTitle
            timeslotReferred.setOnClickListener(action)
            ratingDate.text = SimpleDateFormat.getDateInstance().format(rating.date.toDate())
            if (rating.title != null && rating.title.isNotEmpty()) {
                title.text = comment(rating.title)
                title.visibility = VISIBLE
            } else {
                title.visibility = GONE
            }
            if (rating.comment != null && rating.comment.isNotEmpty()) {
                comment.text = comment(rating.comment)
                comment.visibility = VISIBLE
            } else {
                comment.visibility = GONE
            }
        }

        fun unbind() {
            timeslotReferred.setOnClickListener(null)
        }
    }

    private var ratings = mutableListOf<Rate>()
    private var timeslotsReferred = mutableListOf<TimeSlot>()
    private var ratingUsers = mutableListOf<User>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RatingHolder {
        val item = LayoutInflater.from(parent.context).inflate(R.layout.rating_item, parent, false)
        return RatingHolder(item)
    }

    override fun onBindViewHolder(holder: RatingHolder, position: Int) {
        holder.bind(ratings[position], ratingUsers[position].fullname, timeslotsReferred[position].title, action = {
            fragment.openTimeslotDetailFragment(timeslotsReferred[position].id!!)
        }, role = if (timeslotsReferred[position].userID == ratingUsers[position].id) "Provider" else "Receiver", ratingUsers[position].profile_picture, fragment.requireContext())
    }

    override fun onViewRecycled(holder: RatingHolder) {
        holder.unbind()
    }

    fun setRatingsList(listRatings: List<Rate>, listRatingUsers: List<User>, listTimeslotsReferred: List<TimeSlot>) {
        val ratingsDiffCallback = RatingsDiffCallback(ratings, listRatings)
        val ratingsDiffResult = DiffUtil.calculateDiff(ratingsDiffCallback)
        ratings = listRatings.toMutableList()
        ratingUsers = listRatingUsers.toMutableList()
        timeslotsReferred = listTimeslotsReferred.toMutableList()
        ratingsDiffResult.dispatchUpdatesTo(this)
    }

    override fun getItemCount(): Int = ratings.size
}

class RatingsDiffCallback(private val oldList: List<Rate>, private val newList: List<Rate>): DiffUtil.Callback() {
    override fun getOldListSize(): Int = oldList.size

    override fun getNewListSize(): Int = newList.size

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition].id == newList[newItemPosition].id

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean = oldList[oldItemPosition] == newList[newItemPosition]
}