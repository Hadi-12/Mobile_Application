package it.polito.timebanking

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class RatingViewModel : ViewModel() {

    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    @Suppress("unused")
    fun getRate(id: String): LiveData<Rate?> {
        val rateMutableLiveData = MutableLiveData<Rate?>()
        db.collection("rating").document(id).addSnapshotListener { documentSnapshot, error ->
            if (error != null) {
                Log.e("TIMEBANKING", "GET RATE: ${error.localizedMessage}")
                rateMutableLiveData.postValue(null)
                return@addSnapshotListener
            }
            if (documentSnapshot != null && documentSnapshot.exists()) {
                val rate = documentSnapshot.toRate(documentSnapshot.id)
                rateMutableLiveData.postValue(rate)
            } else {
                Log.e("TIMEBANKING", "GET RATE : rate doesn't exist")
                rateMutableLiveData.postValue(null)
            }
        }
        return rateMutableLiveData
    }


    fun setRate(rate: Rate): MutableLiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        val document = if (rate.id != null) {
            db.collection("rating").document(rate.id!!)
        } else {
            db.collection("rating").document()
        }
        rate.id = document.id
        document.set(rate).addOnSuccessListener {
            Log.d("TIMEBANKING", "Rate set/updated correctly!")
            result.postValue(true)
        }.addOnFailureListener {
            Log.e("TIMEBANKING", "Error setting/updating rate!")
            result.postValue(false)
        }
        return result
    }

    fun getAverageRatingForUser(userID: String): LiveData<Int?> {
        val result = MutableLiveData<Int?>()
        db.collection("rating").whereEqualTo("userIDRated", userID)
            .addSnapshotListener { value, error ->
                if (error == null && value != null) {
                    val listOfStars = value.mapNotNull { r -> r.toRate(r.id)?.numStars }
                    result.postValue(listOfStars.average().toInt())
                } else {
                    Log.e(
                        "TIMEBANKING",
                        "GET AVERAGE RATING FOR USER Couldn't get average rating for user"
                    )
                    result.postValue(null)
                }
            }
        return result
    }

    fun getUserRateOfTimeslot(userID : String, timeSlotID: String) : LiveData<Pair<String?, Rate?>>{
        val rateMutableLiveData = MutableLiveData<Pair<String?, Rate?>>()
        db.collection("rating").whereEqualTo("userIDRating", userID).whereEqualTo("timeSlotID", timeSlotID)
            .addSnapshotListener{value, error ->
                if (error != null) {
                    Log.e("TIMEBANKING", "GET RATE: ${error.localizedMessage}")
                    rateMutableLiveData.postValue(Pair(null, null))
                    return@addSnapshotListener
                }
                if (value != null) {
                    val listOfRatings = value.mapNotNull { r -> r.toRate(r.id) }
                    if(listOfRatings.isNotEmpty())
                        rateMutableLiveData.postValue(Pair("FOUND", listOfRatings[0]))
                    else rateMutableLiveData.postValue(Pair("EMPTY", null))
                } else {
                    Log.e("TIMEBANKING", "GET RATE : rate doesn't exist")
                    rateMutableLiveData.postValue(Pair(null, null))
                }
            }
        return rateMutableLiveData
    }


    fun getRatingsForUser(
        userID: String,
        orderedBy: String,
        direction: Query.Direction
    ): LiveData<List<Pair<Rate, Pair<User, TimeSlot>>?>?> {
        val result = MutableLiveData<List<Pair<Rate, Pair<User, TimeSlot>>?>?>()
        var contatore = 0
        db.collection("rating").whereEqualTo("userIDRated", userID).orderBy(orderedBy, direction)
            .addSnapshotListener { value, error ->
                if (error == null && value != null) {
                    val listOfRatings = value.mapNotNull { r -> Pair(contatore++, r.toRate(r.id)) }
                    val list = MutableList<Pair<Rate, Pair<User, TimeSlot>>?>(listOfRatings.size) { null }
                    var shouldBreak = false
                    for (rating in listOfRatings) {
                        if (shouldBreak) break
                        db.collection("timeslots").document(rating.second!!.timeSlotID).get()
                            .addOnCompleteListener { timeslotResult ->
                                if (timeslotResult.isSuccessful) {
                                    val timeslot =
                                        timeslotResult.result.toTimeSlot(timeslotResult.result.id)
                                    if (timeslot != null) {
                                        db.collection("users").document(rating.second!!.userIDRating).get()
                                            .addOnCompleteListener { userResult ->
                                                if (userResult.isSuccessful) {
                                                    val user = userResult.result.toUser(rating.second!!.userIDRating)
                                                    if (user != null) {
                                                        list[rating.first] = Pair(rating.second!!, Pair(user, timeslot))
                                                        result.postValue(list)
                                                        if (list.filterNotNull().size == listOfRatings.size) contatore = 0
                                                    } else {
                                                        shouldBreak = true
                                                        Log.e(
                                                            "TIMEBANKING",
                                                            "GET RATINGS FOR USER Couldn't parse rating user"
                                                        )
                                                        result.postValue(null)
                                                    }
                                                } else {
                                                    shouldBreak = true
                                                    Log.e(
                                                        "TIMEBANKING",
                                                        "GET RATINGS FOR USER Couldn't get rating user"
                                                    )
                                                    result.postValue(null)
                                                }
                                            }
                                    } else {
                                        shouldBreak = true
                                        Log.e(
                                            "TIMEBANKING",
                                            "GET RATINGS FOR USER Couldn't parse timeslot referred"
                                        )
                                        result.postValue(null)
                                    }
                                } else {
                                    shouldBreak = true
                                    Log.e(
                                        "TIMEBANKING",
                                        "GET RATINGS FOR USER Couldn't get timeslot referred"
                                    )
                                    result.postValue(null)
                                }
                            }
                    }
                } else {
                    Log.e("TIMEBANKING", "GET RATINGS FOR USER Couldn't get ratings for user")
                    result.postValue(null)
                }
            }
        return result
    }
}

    data class Rate(
        val userIDRated: String,
        val userIDRating: String,
        val timeSlotID: String,
        val numStars: Int,
        val comment: String?,
        val title: String?,
        val date: Timestamp,
        @get:Exclude
        var id : String?
    )

    fun DocumentSnapshot.toRate(id: String): Rate? {
        return try {
            val userIDRated = get("userIDRated") as String
            val userIDRating = get("userIDRating") as String
            val timeSlotID = get("timeSlotID") as String
            val numStars = (get("numStars") as Long).toInt()
            val comment = get("comment") as String?
            val title = get("title") as String?
            val date = get("date") as Timestamp

            Rate(
                id = id,
                userIDRated = userIDRated,
                userIDRating = userIDRating,
                timeSlotID = timeSlotID,
                numStars = numStars,
                comment = comment,
                title = title,
                date = date
            )
        } catch (e: Exception) {
            Log.e("TIMEBANKING", "TO_RATE: ${e.localizedMessage!!}")
            null
        }
    }
