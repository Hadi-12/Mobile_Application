package it.polito.timebanking

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.FirebaseFirestore
import kotlin.collections.HashMap

class TimeSlotViewModelFactory(private val application: Application, private val serviceType: String) :
    ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = TimeSlotViewModel(application, serviceType) as T

}

class TimeSlotViewModel(application: Application, private val serviceType: String) : AndroidViewModel(application) {
    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    fun getTimeSlot(id: String) : LiveData<TimeSlot?> {
        val timeslotMutableLiveData = MutableLiveData<TimeSlot?>()
        db.collection("timeslots").document(id).addSnapshotListener { documentSnapshot, error ->
            if (error != null) {
                Log.e("TIMEBANKING", "GET TIMESLOT: ${error.localizedMessage}")
                timeslotMutableLiveData.postValue(null)
                return@addSnapshotListener
            }
            if (documentSnapshot != null && documentSnapshot.exists()) {
                val timeslot = documentSnapshot.toTimeSlot(documentSnapshot.id)
                timeslotMutableLiveData.postValue(timeslot)
            }
            else {
                Log.e("TIMEBANKING", "GET TIMESLOT timeslot doesn't exist")
                timeslotMutableLiveData.postValue(null)
            }
        }
        return timeslotMutableLiveData
    }

    fun setTimeSlot(timeSlot: TimeSlot): MutableLiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        val document = if (timeSlot.id != null) {
                db.collection("timeslots").document(timeSlot.id!!)
            } else {
                db.collection("timeslots").document()
            }
        timeSlot.id = document.id
        document.set(timeSlot).addOnSuccessListener {
            Log.d("TIMEBANKING", "Timeslot set/updated correctly!")
            result.postValue(true)
        }.addOnFailureListener {
            Log.e("TIMEBANKING", "Error setting/updating timeslot!")
            result.postValue(false)
        }
        return result
    }

    fun getOrderedByTitle(): LiveData<List<TimeSlot>> {
        val result = MutableLiveData<List<TimeSlot>>()
        db.collection("timeslots").whereEqualTo("assignedTo", null).get().addOnSuccessListener {
            result.postValue(it.mapNotNull { u -> u.toTimeSlot(u.id) }.filter { u -> u.serviceType == serviceType })
        }
        return result
    }

    fun getOrderedByDate(): LiveData<List<TimeSlot>> {
        val result = MutableLiveData<List<TimeSlot>>()
        db.collection("timeslots").whereEqualTo("assignedTo", null).orderBy("date").get().addOnSuccessListener {
            result.postValue(it.mapNotNull { u -> u.toTimeSlot(u.id) }.filter { u -> u.serviceType == serviceType })
        }
        return result
    }

    fun getOrderedByLocation(): LiveData<List<TimeSlot>> {
        val result = MutableLiveData<List<TimeSlot>>()
        db.collection("timeslots").whereEqualTo("assignedTo", null).orderBy("location").get().addOnSuccessListener {
            result.postValue(it.mapNotNull { u -> u.toTimeSlot(u.id) }.filter { u -> u.serviceType == serviceType })
        }
        return result
    }
    fun deleteTimeSlot(id:String){
        db.collection("timeslots").document(id).delete()
    }

    fun assignTimeslotToUser(timeslotID: String, userID: String): LiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        db.collection("timeslots").document(timeslotID).update("assignedTo", userID).addOnCompleteListener {
            if (it.isSuccessful) {
                result.postValue(true)
            } else {
                Log.e("TIMEBANKING", "ASSIGN TIMESLOT TO USER failed")
                result.postValue(false)
            }
        }
        return result
    }

    fun switchInterestedUserToTimeslot(timeslotID: String, userID: String): MutableLiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        db.collection("timeslots").document(timeslotID).get().addOnCompleteListener {
            if (it.isSuccessful) {
                val timeslot = it.result.toTimeSlot(timeslotID)
                if (timeslot != null) {
                    val newList = timeslot.interestedUsers.toMutableList()
                    if (newList.contains(userID)) {
                        newList.remove(userID)
                    } else {
                        newList.add(userID)
                    }
                    db.collection("timeslots").document(timeslotID).update("interestedUsers", newList).addOnCompleteListener { addResult ->
                        if (addResult.isSuccessful) {
                            result.postValue(true)
                        } else {
                            Log.e("TIMEBANKING", "SWITCH INTERESTED USER TO TIMESLOT Couldn't switch user interest status")
                            result.postValue(false)
                        }
                    }
                } else {
                    Log.e("TIMEBANKING", "ADD INTERESTED USER TO TIMESLOT Couldn't parse timeslot")
                    result.postValue(false)
                }
            } else {
                Log.e("TIMEBANKING", "ADD INTERESTED USER TO TIMESLOT Couldn't get timeslot")
                result.postValue(false)
            }
        }
        return result
    }

    fun getFavoritesOfUser(userID: String, orderedBy: String): LiveData<List<TimeSlot>?> {
        val result = MutableLiveData<List<TimeSlot>?>()
        db.collection("timeslots").whereArrayContains("interestedUsers", userID).orderBy(orderedBy).get().addOnCompleteListener {
            if (it.isSuccessful) {
                result.postValue(it.result.mapNotNull { u -> u.toTimeSlot(u.id) })
            }
            else {
                Log.e("TIMEBANKING", "Could not get user favorites: ${it.exception?.localizedMessage}")
                result.postValue(null)
            }
        }
        return result
    }

    fun getTimeslotsCreatedByUser(userID: String, orderedBy: String): LiveData<List<TimeSlot>?> {
        val result = MutableLiveData<List<TimeSlot>?>()
        db.collection("timeslots").whereEqualTo("userID", userID).orderBy(orderedBy).get().addOnCompleteListener {
            if (it.isSuccessful) {
                result.postValue(it.result.mapNotNull { u -> u.toTimeSlot(u.id) })
            } else {
                Log.e("TIMEBANKING", "Could not get user offers: ${it.exception?.localizedMessage}")
                result.postValue(null)
            }
        }
        return result
    }
}

data class TimeSlot(
    val userID: String,
    val title: String = "",
    val description: String = "",
    val serviceType: String,
    val date: Timestamp,
    val duration: Duration,
    val location: String,
    val interestedUsers: List<String> = emptyList(),
    val assignedTo: String? = null,
    @get:Exclude
    var id: String?
)

data class Duration (
    val hours: Int,
    val minutes: Int
)



fun String.toDuration(): Duration? {
    fun isNumber(s: String?): Boolean {
        return if (s.isNullOrEmpty()) false else s.all { Character.isDigit(it) }
    }
    val list = mutableListOf<Int>()
    val splitted = split(" ")
    for(el in splitted) {
        if(isNumber(el)) {
            list.add(el.toInt())
        }
    }
    if (splitted.size == 2 && list.size == 1) {
        if (splitted[1].startsWith("hour")) {
            return Duration(hours = list[0], minutes = 0)
        }
        else if (splitted[1].startsWith("minute")) {
            return Duration(hours = 0, minutes = list[0])
        }
    }
    else if (splitted.size == 5 && list.size == 2) {
        return Duration(hours = list[0], minutes = list[1])
    }
    return null
}

fun Duration.representAsString(): String {
    fun concat(vararg string: String): String {
        val sb = StringBuilder()
        for (s in string) {
            sb.append(s)
        }

        return sb.toString()
    }
    var durationStr = ""
    if (hours != 0) {
        durationStr = concat(hours.toString(), " hour")
        if (hours > 1) {
            durationStr = concat(durationStr, "s")
        }
        if (minutes != 0) {
            durationStr = concat(durationStr, " and ")
        }
    }
    if (minutes != 0) {
        durationStr = concat(durationStr, minutes.toString(), " minutes")
    }
    return durationStr
}

fun DocumentSnapshot.toTimeSlot(id: String): TimeSlot? {
    return try {
        val title = get("title") as String
        val userID = get("userID") as String
        val description = get("description") as String
        val serviceType = get("serviceType") as String
        val date = get("date") as Timestamp
        val durationRaw = get("duration") as HashMap<*, *>
        val duration = Duration(hours = (durationRaw["hours"] as Long).toInt(), minutes = (durationRaw["minutes"] as Long).toInt())
        val location = get("location") as String
        val interestedUsers = (get("interestedUsers") as List<*>).filterIsInstance<String>()
        val assignedTo = get("assignedTo") as String?
        TimeSlot(
            id = id,
            userID = userID,
            title = title,
            description = description,
            serviceType = serviceType,
            date = date,
            duration = duration,
            location = location,
            interestedUsers = interestedUsers,
            assignedTo = assignedTo
        )
    } catch (e: Exception) {
        Log.e("TIMEBANKING", "TO_TIMESLOT: ${e.localizedMessage}")
        null
    }
}