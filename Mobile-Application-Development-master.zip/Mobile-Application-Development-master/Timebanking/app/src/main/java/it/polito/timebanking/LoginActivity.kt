package it.polito.timebanking

import android.content.Intent
import android.content.IntentSender
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.auth.api.identity.BeginSignInRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.SignInClient
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        oneTapClient = Identity.getSignInClient(this)
        signInRequest = BeginSignInRequest.builder()
            .setGoogleIdTokenRequestOptions(
                BeginSignInRequest.GoogleIdTokenRequestOptions.builder()
                    .setSupported(true)
                    .setServerClientId(getString(R.string.web_client_id))
                    .setFilterByAuthorizedAccounts(false)
                    .build())
            .build()
        findViewById<SignInButton>(R.id.sign_in_button).setOnClickListener {
            oneTapClient
                .beginSignIn(signInRequest)
                .addOnSuccessListener(this) { result ->
                    try {
                        val intentSender = IntentSenderRequest.Builder(result.pendingIntent.intentSender).build()
                        resultLauncher.launch(intentSender)
                    } catch (e: IntentSender.SendIntentException) {
                        Log.e("TIMEBANKING", "Couldn't start One Tap UI: ${e.localizedMessage}")
                    }
                }
                .addOnFailureListener(this) { e ->
                    Log.d("TIMEBANKING", "ONE_TAP_CLIENT FAILURE: ${e.localizedMessage!!}")
                    Snackbar.make(findViewById(R.id.login_parent_layout), "There was an error signing in. Make sure to have a Google account set up on this device", Snackbar.LENGTH_LONG).show()
                }
        }
    }

    private lateinit var oneTapClient: SignInClient
    private lateinit var signInRequest: BeginSignInRequest
    private var resultLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        try {
            val credential = oneTapClient.getSignInCredentialFromIntent(result.data)
            val idToken = credential.googleIdToken
            when {
                idToken != null -> {
                    Log.d("TIMEBANKING", "Got ID token.")
                    val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                    Firebase.auth.signInWithCredential(firebaseCredential)
                        .addOnCompleteListener(this) { task ->
                            if (task.isSuccessful) {
                                Log.d("TIMEBANKING", "signInWithCredential:success")
                                val intent = Intent(this, MainActivity::class.java)
                                val additionalUserInfo = task.result.additionalUserInfo
                                if (additionalUserInfo != null && additionalUserInfo.isNewUser) {
                                    intent.putExtra("NEW_USER", true)
                                }
                                startActivity(intent)
                                finish()
                            } else {
                                Log.w("TIMEBANKING", "signInWithCredential:failure", task.exception)
                            }
                        }
                }
                else -> {
                    // Shouldn't happen.
                    Log.d("TIMEBANKING", "No ID token!")
                }
            }
        } catch (e: ApiException) {
            Log.e("TIMEBANKING", "ApiException: ${e.localizedMessage}")
        }
    }
}