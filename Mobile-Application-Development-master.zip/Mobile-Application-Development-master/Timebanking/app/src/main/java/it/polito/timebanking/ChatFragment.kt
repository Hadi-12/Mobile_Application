package it.polito.timebanking

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.view.View.*
import android.widget.*
import androidx.activity.addCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import java.io.File
import java.util.*


class ChatFragment:Fragment(R.layout.chat_fragment_layout) {
    private lateinit var _resultLauncherImage: ActivityResultLauncher<Intent>
    private lateinit var _resultLauncher: ActivityResultLauncher<Intent>
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var attachBtn: ImageButton
    private lateinit var sendBtn: ImageButton
    private lateinit var chatMessageEditText: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapterMessages: MessageAdapter
    private lateinit var timeslotReferredTV: TextView
    private lateinit var acceptButton: Button
    private lateinit var timeslotActionsLayout: RelativeLayout
    private lateinit var timeslotAssignedTV: TextView
    private val usersViewModel: UserViewModel by activityViewModels()
    private val ratingViewModel : RatingViewModel by activityViewModels()
    private val conversationsViewModel: ConversationViewModel by activityViewModels()
    private val timeSlotsViewModel by activityViewModels<TimeSlotViewModel> {
        TimeSlotViewModelFactory(requireActivity().application, "All")
    }
    private lateinit var topAppBar: MaterialToolbar
    private var imageUri: Uri? = null
    private val args: ChatFragmentArgs by navArgs()
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setNavDrawerEnabled(false)
        sharedPreferences = requireActivity().getSharedPreferences(
            "user_preferences",
            Context.MODE_PRIVATE
        ) as SharedPreferences
        requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
                if (isGranted) {
                    openGallery()
                } else {
                    sharedPreferences.edit().putInt(
                        "DONT_ASK_PERMISSION",
                        sharedPreferences.getInt("DONT_ASK_PERMISSION", 0) + 1
                    ).apply()
                    showPermissionDeniedDialog()
                }
            }
        _resultLauncherImage =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    imageUri?.let { sendImageMessage(it) }
                }
            }
        _resultLauncher =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    // There are no request codes
                    val data: Intent? = result.data
                    val imageUri: Uri? = data?.data
                    imageUri?.let { sendImageMessage(it) }
                }
            }
        attachBtn = view.findViewById(R.id.attach_btn)
        attachBtn.setOnClickListener{
            showImagePicDialog()
        }
        topAppBar = requireActivity().findViewById(R.id.topAppBar) as MaterialToolbar
        topAppBar.title = "Chat"
        recyclerView = view.findViewById(R.id.chat_fragment_recycle_view)
        adapterMessages = MessageAdapter(this, usersViewModel, requireContext())
        recyclerView.adapter = adapterMessages
        timeslotReferredTV = view.findViewById(R.id.timeslot_referred_chat_tv)
        acceptButton = view.findViewById(R.id.accept_timeslot_button_in_chat)
        timeslotActionsLayout = view.findViewById(R.id.actions_in_chat_rl)
        timeslotAssignedTV = view.findViewById(R.id.timeslot_accepted_tv)
        conversationsViewModel.getConversation(args.conversationId).observe(viewLifecycleOwner) {
            if (it != null) {
                val otherUserUID = if (it.user1 == FirebaseAuth.getInstance().currentUser!!.uid) it.user2 else it.user1
                usersViewModel.getUser(otherUserUID).observe(viewLifecycleOwner) { otherUser ->
                    if (otherUser != null) {
                        topAppBar.title = otherUser.fullname
                        topAppBar.subtitle = otherUser.status
                        topAppBar.setOnClickListener {
                            resetSubtitle()
                            findNavController().navigate(ChatFragmentDirections.actionChatFragmentToShowProfileFragment(otherUserUID))
                        }
                        timeSlotsViewModel.getTimeSlot(it.timeslot_referred).observe(viewLifecycleOwner) { timeslot_referred ->
                            if (timeslot_referred != null) {
                                if(timeslot_referred.assignedTo != null && convertDurationIntoTimestamp(timeslot_referred.duration, timeslot_referred.date).before(Calendar.getInstance().time)){
                                    ratingViewModel.getUserRateOfTimeslot(FirebaseAuth.getInstance().currentUser!!.uid, timeslot_referred.id!!).observe(viewLifecycleOwner) { result ->
                                        if (result.first == null) {
                                            Snackbar.make(requireView(), "Couldn't retrieve ratings information", Snackbar.LENGTH_SHORT).show()
                                        } else if(result.second == null) {
                                            rateAlertDialog(timeslot_referred, otherUser)
                                            val showRatingRelativeLayout : RelativeLayout = view.findViewById(R.id.rating_in_chat_rl)
                                            showRatingRelativeLayout.visibility = GONE

                                            val setRateRelativeLayout : RelativeLayout = view.findViewById(R.id.rate_in_chat_rl)
                                            setRateRelativeLayout.visibility = VISIBLE

                                            val rateBtn : ImageButton = view.findViewById(R.id.rate_in_chat_btn)

                                            rateBtn.setOnClickListener { rateAlertDialog(timeslot_referred, otherUser) }
                                        } else {
                                            val setRateRelativeLayout : RelativeLayout = view.findViewById(R.id.rate_in_chat_rl)
                                            setRateRelativeLayout.visibility = GONE

                                            val showRatingRelativeLayout : RelativeLayout = view.findViewById(R.id.rating_in_chat_rl)
                                            showRatingRelativeLayout.visibility = VISIBLE

                                            val rateBar : RatingBar = view.findViewById(R.id.rating_bar)

                                            rateBar.rating = result.second!!.numStars.toFloat()


                                            val title : TextView = view.findViewById(R.id.rating_title_in_chat_tv)
                                            if(result.second!!.title.toString().isNotEmpty()){
                                                title.text = result.second!!.title.toString()
                                            } else {
                                                title.visibility = GONE
                                            }
                                        }
                                    }
                                }
                                timeslotReferredTV.text = timeslot_referred.title
                                if (it.user1 == FirebaseAuth.getInstance().currentUser!!.uid) {
                                    if (timeslot_referred.assignedTo != null) {
                                        acceptButton.visibility = GONE
                                        timeslotAssignedTV.text = getString(
                                            R.string.assigned_to_with_param,
                                            otherUser.fullname
                                        )
                                        timeslotAssignedTV.visibility = VISIBLE
                                    }
                                    else {
                                        acceptButton.visibility = VISIBLE
                                        acceptButton.setOnClickListener {
                                            MaterialAlertDialogBuilder(requireContext())
                                                .setTitle("Confirm")
                                                .setMessage("Are you sure you want to assign this timeslot to ${otherUser.fullname}?")
                                                .setPositiveButton("Yes") { _, _ ->
                                                    timeSlotsViewModel.assignTimeslotToUser(
                                                        timeslot_referred.id!!,
                                                        otherUserUID
                                                    ).observe(viewLifecycleOwner) { assignResult ->
                                                        if (assignResult) {
                                                            usersViewModel.creditExchange(timeslot_referred.duration, otherUserUID, timeslot_referred.userID).observe(viewLifecycleOwner) { editResult ->
                                                                if (editResult) {
                                                                    acceptButton.visibility = GONE
                                                                    timeslotAssignedTV.text =
                                                                        getString(
                                                                            R.string.assigned_to_with_param,
                                                                            otherUser.fullname
                                                                        )
                                                                    timeslotAssignedTV.visibility =
                                                                        VISIBLE
                                                                } else {
                                                                    Snackbar.make(
                                                                        requireView(),
                                                                        "Couldn't edit credits. Try again",
                                                                        Snackbar.LENGTH_SHORT
                                                                    ).show()
                                                                }
                                                            }
                                                        }else{
                                                            Snackbar.make(
                                                                requireView(),
                                                                "Couldn't assign timeslot to other user. Try again",
                                                                Snackbar.LENGTH_SHORT
                                                            ).show()
                                                        }
                                                    }
                                                }
                                                .setNegativeButton("No") { dialog, _ ->
                                                    dialog.dismiss()
                                                }.show()
                                        }
                                    }
                                }
                                else {
                                    if (timeslot_referred.assignedTo != null && timeslot_referred.assignedTo == FirebaseAuth.getInstance().currentUser!!.uid) {
                                        timeslotAssignedTV.text = getString(R.string.assigned_to_with_param, "you!")
                                        timeslotAssignedTV.visibility = VISIBLE
                                    }
                                }
                            } else {
                                Snackbar.make(requireView(), "Couldn't find timeslot referred", Snackbar.LENGTH_SHORT).show()
                                resetSubtitle()
                                findNavController().navigateUp()
                            }
                        }
                    } else {
                        Snackbar.make(requireView(), "Other user not found", Snackbar.LENGTH_SHORT).show()
                        resetSubtitle()
                        findNavController().navigateUp()
                    }
                }
                adapterMessages.setChatList(it.chats)
                updateMessageRead()
                val position = (recyclerView.layoutManager as LinearLayoutManager).findFirstVisibleItemPosition()
                recyclerView.scrollToPosition(position)
            } else {
                Log.e("TIMEBANKING", "Conversation ID not found in database")
            }
        }
        chatMessageEditText = view.findViewById(R.id.chat_message_et)
        sendBtn = view.findViewById(R.id.send_msg_btn)
        sendBtn.setOnClickListener {
            if(chatMessageEditText.text.toString().isNotEmpty())
                sendMessage(chatMessageEditText.text.toString().trim())
            chatMessageEditText.setText("")
        }
        val chatMessageEditTextWatcher = object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
            }
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().isNotEmpty() && p0.endsWith('\n')) {
                        sendMessage(chatMessageEditText.text.toString().trim())
                        chatMessageEditText.setText("")
                    }
                }
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
        }
        chatMessageEditText.addTextChangedListener(chatMessageEditTextWatcher)
        requireActivity().onBackPressedDispatcher.addCallback(this) {
            resetSubtitle()
            findNavController().navigateUp()
        }
        setHasOptionsMenu(true)
    }

    private fun resetSubtitle() {
        topAppBar.subtitle = ""
        setNavDrawerEnabled(true)
    }

    private fun setNavDrawerEnabled(value: Boolean) {
        if (value)
            requireActivity().findViewById<DrawerLayout>(R.id.drawer_layout)
                .setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
        else requireActivity().findViewById<DrawerLayout>(R.id.drawer_layout)
            .setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                resetSubtitle()
                findNavController().navigateUp()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun updateMessageRead() {
        conversationsViewModel.updateMessageRead(args.conversationId).observe(viewLifecycleOwner) {
            if(!it) {
                Log.e("TIMEBANKING", "SET MESSAGE DELIVERED in fragment chat: could not set message delivered!")
            }
        }
    }

    private fun sendImageMessage(fileUri:Uri) {
        val progressBar = ProgressBar(requireContext(), null, android.R.attr.progressBarStyleLarge)
        val params = RelativeLayout.LayoutParams(100, 100)
        params.addRule(RelativeLayout.CENTER_IN_PARENT)
        requireView().findViewById<RelativeLayout>(R.id.chat_fragment_rl).addView(progressBar, params)
        progressBar.visibility = VISIBLE
        val fileName = UUID.randomUUID().toString() +".jpg"
        val refStorage = FirebaseStorage.getInstance().reference.child("images/$fileName")
        val msgText = chatMessageEditText.text.toString().trim()
        chatMessageEditText.setText("")
        refStorage.putFile(fileUri).addOnSuccessListener { taskSnapshot ->
            taskSnapshot.storage.downloadUrl.addOnSuccessListener {
                val imageUri = it.toString()
                conversationsViewModel.sendMessage(args.conversationId, msgText, imageUri).observe(viewLifecycleOwner) { result ->
                    if (!result) {
                        Snackbar.make(requireView(), "Error in sending message with image", Snackbar.LENGTH_SHORT).show()
                        chatMessageEditText.setText(msgText)
                    }
                    progressBar.visibility = GONE
                }
            }
        }.addOnFailureListener { e ->
            Log.e("TIMEBANKING", "Send image message failed: ${e.localizedMessage}")
        }
    }
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
       _resultLauncher.launch(intent)
    }
    private fun createImageFile(): Uri? {
        val storageDir: File? =
            requireActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return Uri.fromFile(
            File.createTempFile(
                "JPEG_PICTURE_TIMEBANKING_", /* prefix */
                ".jpg", /* suffix */
                storageDir /* directory */
            )
        )
    }

   private fun pickFromCamera() {
      val profilePicture = createImageFile()
       imageUri = FileProvider.getUriForFile(
           requireContext(),
           "it.polito.fileprovider",
           File(profilePicture?.path!!)
       )
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
       _resultLauncherImage.launch(cameraIntent)
    }


    private fun sendMessage(message: String) {
        conversationsViewModel.sendMessage(args.conversationId, message, null).observe(viewLifecycleOwner) {
            if (!it) {
                Snackbar.make(requireView(), "Error in message sending", Snackbar.LENGTH_SHORT).show()
            }
        }
    }
    private fun showImagePicDialog() {
        val options = arrayOf("Camera", "Gallery")
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Pick Image From")
        builder.setItems(options) { _, which ->
            if (which == 0) {
                pickFromCamera()
            } else if (which == 1) {
                when {
                    ContextCompat.checkSelfPermission(
                        requireContext(),
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED -> {
                        openGallery()
                    }
                    shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE) -> {
                        MaterialAlertDialogBuilder(requireContext()).setTitle("Memory permissions")
                            .setMessage("Please grant memory access permission to use this functionality")
                            .setNegativeButton("No thanks", null)
                            .setPositiveButton("Ok") { _, _ ->
                                requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                            }
                            .show()
                    }
                    else -> {
                        requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                    }
                }
            }
        }
        builder.create().show()
    }

    private fun showPermissionDeniedDialog() {
        if (sharedPreferences.getInt("DONT_ASK_PERMISSION", 0) < 2) {
            MaterialAlertDialogBuilder(activity as Context).setTitle("Permission Denied")
                .setMessage("To use this functionality, memory access permission is required. Do you want to grant it?")
                .setPositiveButton(
                    "Ok"
                ) { _, _ ->
                    requestPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
                .setNegativeButton("No", null)
                .show()
        } else {
            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Permission Denied")
                .setMessage("Permission is denied, please allow permissions from App Settings.")
                .setPositiveButton(
                    "App Settings"
                ) { _, _ ->
                    val intent = Intent()
                    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                    val uri = Uri.fromParts("package", requireContext().packageName, null)
                    intent.data = uri
                    startActivity(intent)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun checkRate(title : EditText, comment : EditText, ratingBar: RatingBar, ratingView : View) : Boolean{
        if(ratingBar.rating == 0f && title.text.toString().isEmpty() && comment.text.isEmpty()) {
            val error : TextView = ratingView.findViewById(R.id.error)
            error.text = getString(R.string.cannot_save_empty_rate)
            return false
        }

        if(title.text.toString().isEmpty() && comment.text.toString().isNotEmpty()) {
            title.error = getString(R.string.title_cant_be_empty_if_comment)
            return false
        }
        if(title.text.toString().isNotEmpty() && comment.text.isEmpty()) {
            comment.error = getString(R.string.comment_cant_be_empty_if_title)
            return false
        }
        if(ratingBar.rating == 0f) {
            val error : TextView = ratingView.findViewById(R.id.error)
            error.text = getString(R.string.minimum_rating_is_1)
            return false
        }
        return true
    }

    private fun rateAlertDialog(timeslot_referred: TimeSlot, otherUser: User) {
        val ratingView: View =
            layoutInflater.inflate(R.layout.rating, null)

        val title: EditText =
            ratingView.findViewById(R.id.title)
        val comment: EditText =
            ratingView.findViewById(R.id.comment)
        val ratingBar: RatingBar =
            ratingView.findViewById(R.id.rating)
        val starsDrawable = ratingBar.progressDrawable as LayerDrawable
        starsDrawable.getDrawable(2).colorFilter = PorterDuffColorFilter(ContextCompat.getColor(requireContext(), R.color.purple_500), PorterDuff.Mode.SRC_ATOP)
        starsDrawable.getDrawable(1).colorFilter = PorterDuffColorFilter(ContextCompat.getColor(requireContext(), R.color.white), PorterDuff.Mode.SRC_ATOP)
        starsDrawable.getDrawable(0).colorFilter = PorterDuffColorFilter(ContextCompat.getColor(requireContext(), android.R.color.darker_gray), PorterDuff.Mode.SRC_ATOP)
        val rateAlertDialog =
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(
                    "Rate " + otherUser.fullname + " for " +
                            timeslot_referred.title
                )
                .setView(ratingView)
                .setPositiveButton("Save", null)
                .setNegativeButton("Close") { dialog, _ ->
                    dialog.dismiss()
                }.show()

        rateAlertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setOnClickListener {
                if (checkRate(
                        title,
                        comment,
                        ratingBar,
                        ratingView
                    )
                ) {
                    val rate = Rate(
                        id = null,
                        userIDRated = otherUser.id,
                        userIDRating = FirebaseAuth.getInstance().currentUser!!.uid,
                        timeSlotID = timeslot_referred.id!!,
                        numStars = ratingBar.rating.toInt(),
                        comment = comment.text.toString(),
                        title = title.text.toString(),
                        date = Timestamp.now()
                    )

                    ratingViewModel.setRate(rate).observe(viewLifecycleOwner) {
                        if (it) {
                            val setRateRelativeLayout : RelativeLayout = requireView().findViewById(R.id.rate_in_chat_rl)
                            setRateRelativeLayout.visibility = GONE

                            val rateBar : RatingBar = requireView().findViewById(R.id.rating_bar)

                            rateBar.rating = rate.numStars.toFloat()


                            if(rate.title.toString().isNotEmpty()){
                                val titleRating : TextView = requireView().findViewById(R.id.rating_title_in_chat_tv)
                                titleRating.text = rate.title.toString()
                            }
                            rateAlertDialog.dismiss()
                        } else {
                            Snackbar.make(requireView(), "Error setting rate", Snackbar.LENGTH_SHORT).show()
                        }
                    }
                }
            }
    }

    private fun convertDurationIntoTimestamp(duration : Duration, timestamp: Timestamp): Date {
        val date = timestamp.toDate()
        val cal : Calendar = Calendar.getInstance()
        cal.time = date
        cal.add(Calendar.HOUR, duration.hours)
        cal.add(Calendar.MINUTE, duration.minutes)

        return cal.time
    }
}



