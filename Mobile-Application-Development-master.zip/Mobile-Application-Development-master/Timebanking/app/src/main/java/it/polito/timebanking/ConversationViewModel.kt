package it.polito.timebanking

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Exclude
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*
import kotlin.collections.HashMap

class ConversationViewModel: ViewModel() {

    private var db: FirebaseFirestore = FirebaseFirestore.getInstance()

    fun getConversation(conversationID: String): LiveData<Conversation?> {
        val conversationLiveData = MutableLiveData<Conversation?>()
        if (conversationID != "") {
            db.collection("conversations").document(conversationID).addSnapshotListener { documentSnapshot, error ->
                if (error != null) {
                    Log.e("TIMEBANKING", "GET CONVERSATION Snapshot Listener failed: ${error.localizedMessage}")
                    conversationLiveData.postValue(null)
                    return@addSnapshotListener
                }
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    val conversation = documentSnapshot.toConversation(conversationID)
                    conversationLiveData.postValue(conversation)
                }
                else {
                    Log.e("TIMEBANKING", "GET CONVERSATION conversation doesn't exist")
                    conversationLiveData.postValue(null)
                }
            }
        }
        return conversationLiveData
    }

    fun getUserConversations(uid: String): LiveData<List<Conversation>?> {
        val result = MutableLiveData<List<Conversation>?>()
        db.collection("conversations").whereEqualTo("user1", uid).addSnapshotListener { firstSnapshot, firstError ->
            if (firstError != null) {
                Log.e("TIMEBANKING", "GET USER CONVERSATIONS failed(1)")
                result.postValue(null)
                return@addSnapshotListener
            }
            if (firstSnapshot != null) {
                val firstList = firstSnapshot.mapNotNull { c -> c.toConversation(c.id) }
                db.collection("conversations").whereEqualTo("user2", uid).addSnapshotListener { secondSnapshot, secondError ->
                    if (secondError == null && secondSnapshot != null) {
                        result.postValue(firstList.plus(secondSnapshot.mapNotNull { c -> c.toConversation(c.id) }))
                    }
                    else if (secondError != null) {
                        Log.e("TIMEBANKING", "GET USER CONVERSATIONS failed(2)")
                        result.postValue(null)
                    }
                }
            }
        }
        return result
    }

    fun updateMessageRead(conversationID: String): MutableLiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        db.collection("conversations").document(conversationID).get().addOnSuccessListener { documentSnapshot ->
            if (documentSnapshot != null && documentSnapshot.exists()) {
                val conversation = documentSnapshot.toConversation(conversationID)
                if (conversation != null) {
                    for (i in 0 until conversation.chats.size) {
                        if (conversation.chats[i].from != FirebaseAuth.getInstance().currentUser!!.uid)
                            conversation.chats[i].last_delivered = false
                    }
                    if (conversation.chats.any { c -> c.from != FirebaseAuth.getInstance().currentUser!!.uid }) {
                        conversation.chats.first { c -> c.from != FirebaseAuth.getInstance().currentUser!!.uid }.last_delivered =
                            true
                        db.collection("conversations").document(conversationID).set(conversation)
                            .addOnCompleteListener {
                                if (it.isSuccessful) {
                                    result.postValue(true)
                                } else {
                                    Log.e(
                                        "TIMEBANKING",
                                        "SET MESSAGE DELIVERED messages could not be set as read"
                                    )
                                    result.postValue(false)
                                }
                            }
                    }
                } else {
                    Log.e("TIMEBANKING", "SET MESSAGE DELIVERED conversation could not be parsed")
                    result.postValue(false)
                }
            }
            else {
                Log.e("TIMEBANKING", "SET MESSAGE DELIVERED conversation doesn't exist")
                result.postValue(false)
            }
        }
        return result
    }

    fun getConversationIDFromTimeslotReferredAndUsersOrCreate(timeslotID: String, user1: String, user2: String): MutableLiveData<Any?> {
        val id = MutableLiveData<Any?>()
        db.collection("conversations").whereEqualTo("timeslot_referred", timeslotID).whereEqualTo("user1", user1).whereEqualTo("user2", user2).limit(1).get().addOnCompleteListener {
            if (it.isSuccessful) {
                if (it.result != null && it.result.documents.isNotEmpty()) {
                    val document = it.result.documents[0]
                    if (document != null && document.exists()) {
                        id.postValue(document.id)
                    }
                    else {
                        id.postValue(null)
                        Log.e("TIMEBANKING", "GET CONVERSATION FROM DATA Conversation does not exist(1)")
                    }
                } else {
                    id.postValue(-1)
                }
            }
            else {
                id.postValue(null)
                Log.e("TIMEBANKING", "GET CONVERSATION FROM DATA failed")
            }
        }
        return id
    }

    fun createConversation(timeslotID: String, user1: String, user2: String, timeslotTitle: String): MutableLiveData<String?> {
        val id = MutableLiveData<String?>()
        val firstChat = Chat(
            from = user2,
            text = "Hi! I am interested in your offer of ${timeslotTitle}! Let's see if we can arrange something!",
            attachment = null,
            timestamp = Calendar.getInstance().time,
            last_delivered = false
        )
        val conversationToAdd = Conversation(
            user1 = user1,
            user2 = user2,
            chats = listOf(firstChat),
            timeslot_referred = timeslotID
        )
        db.collection("conversations").add(conversationToAdd).addOnCompleteListener {
            if (it.isSuccessful) {
                id.postValue(it.result.id)
            }
            else {
                Log.e("TIMEBANKING", "CREATE CONVERSATION error in creating conversation")
                id.postValue(null)
            }
        }
        return id
    }

    fun sendMessage(conversationID: String, message: String?, picture: String?): MutableLiveData<Boolean> {
        val result = MutableLiveData<Boolean>()
        db.collection("conversations").document(conversationID).get().addOnSuccessListener { documentSnapshot ->
            if (documentSnapshot != null && documentSnapshot.exists()) {
                val conversation = documentSnapshot.toConversation(conversationID)
                if (conversation != null) {
                    val chatToAdd = Chat(
                        from = FirebaseAuth.getInstance().currentUser!!.uid,
                        text = message,
                        attachment = picture,
                        timestamp = Calendar.getInstance().time,
                        last_delivered = false
                    )
                    val mutableList = conversation.chats.toMutableList()
                    mutableList.add(chatToAdd)
                    mutableList.sortByDescending { it.timestamp }
                    conversation.chats = mutableList
                    db.collection("conversations").document(conversationID).set(conversation).addOnCompleteListener {
                        if (it.isSuccessful) {
                            result.postValue(true)
                        }
                        else {
                            Log.e("TIMEBANKING", "SET MESSAGE DELIVERED conversation could not be updated")
                            result.postValue(false)
                        }
                    }
                } else {
                    Log.e("TIMEBANKING", "SEND MESSAGE conversation could not be parsed")
                    result.postValue(false)
                }
            }
            else {
                Log.e("TIMEBANKING", "SEND MESSAGE conversation doesn't exist")
                result.postValue(false)
            }
        }
        return result
    }
}

data class Conversation(
    var user1: String = "",
    var user2: String = "",
    var chats: List<Chat> = emptyList(),
    var timeslot_referred: String = "",
    @get:Exclude
    var id: String = ""
)

data class Chat(
    var from: String = "",
    var text: String?,
    var attachment: String?,
    var timestamp: Date,
    var last_delivered: Boolean
)


fun DocumentSnapshot.toConversation(id: String): Conversation? {
    return try {
        val user1 = get("user1") as String
        val user2 = get("user2") as String
        val chatsRaw = (get("chats") as List<*>)
        val chats = mutableListOf<Chat>()
        for (el in chatsRaw) {
            val mapped = el as HashMap<*, *>
            chats.add(
                Chat(
                    from = mapped["from"] as String,
                    text = (
                            if(mapped["text"] as String? == "")
                                null
                            else
                                mapped["text"] as String?
                            ),
                    attachment = (
                            if(mapped["attachment"] as String? == "")
                                null
                            else
                                mapped["attachment"] as String?
                            ),
                    timestamp = (mapped["timestamp"] as Timestamp).toDate(),
                    last_delivered = mapped["last_delivered"] as Boolean
                )
            )
        }
        chats.sortByDescending { it.timestamp }
        val timeslotReferred = get("timeslot_referred") as String
        Conversation(
            id = id,
            user1 = user1,
            user2 = user2,
            chats = chats,
            timeslot_referred = timeslotReferred
        )
    } catch (e: Exception) {
        Log.e("TIMEBANKING", "TO_CONVERSATION: ${e.localizedMessage!!}")
        null
    }
}