package it.polito.timebanking

import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Button
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class ShowProfileFragment: Fragment(R.layout.show_profile_fragment_layout) {

    private val userViewModel: UserViewModel by activityViewModels()
    private val ratingViewModel: RatingViewModel by activityViewModels()
    private val args: ShowProfileFragmentArgs by navArgs()
    private lateinit var userId : String
    private lateinit var profilePictureImageView: ImageView
    private lateinit var fullnameTextView: TextView
    private lateinit var creditsTextView: TextView
    private lateinit var nicknameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var locationTextView: TextView
    private lateinit var skillsChipGroup: ChipGroup
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var ratingBar: RatingBar
    private lateinit var viewRatingsButton: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        ratingBar = view.findViewById(R.id.rating_bar_profile_detail)
        viewRatingsButton = view.findViewById(R.id.view_ratings_button)
        profilePictureImageView = view.findViewById(R.id.profile_picture_iv_show_profile)
        fullnameTextView = view.findViewById(R.id.user_fullname_tv)
        nicknameTextView = view.findViewById(R.id.user_nickname_tv)
        emailTextView = view.findViewById(R.id.user_email_tv)
        locationTextView = view.findViewById(R.id.user_location_tv)
        skillsChipGroup = view.findViewById(R.id.skills_chip_group_show)
        creditsTextView = view.findViewById(R.id.credits_tv)
        sharedPreferences = activity?.getSharedPreferences("user_preferences", MODE_PRIVATE) as SharedPreferences
        userId = if (args.userUid != null) args.userUid!! else Firebase.auth.currentUser!!.uid
        val user = userViewModel.getUser(userId)
        user.observe(this.viewLifecycleOwner) { userStored ->
            if (userStored != null) {
                Glide.with(requireContext()).load(userStored.profile_picture).into(profilePictureImageView)
                ratingViewModel.getAverageRatingForUser(userId).observe(viewLifecycleOwner) {
                    if (it != null) {
                        if (it == 0) {
                            ratingBar.visibility = GONE
                            viewRatingsButton.text = getString(R.string.no_ratings_yet)
                            viewRatingsButton.isEnabled = false
                        } else {
                            ratingBar.rating = it.toFloat()
                            ratingBar.visibility = VISIBLE
                            viewRatingsButton.text = getString(R.string.view_ratings_label)
                            viewRatingsButton.isEnabled = true
                            viewRatingsButton.setOnClickListener {
                                findNavController().navigate(ShowProfileFragmentDirections.actionShowProfileFragmentToRatingListFragment(userId))
                            }
                        }
                    } else {
                        Snackbar.make(requireView(), "Couldn't compute average rating for user", Snackbar.LENGTH_SHORT).show()
                    }
                }
                fullnameTextView.text = userStored.fullname
                nicknameTextView.text = userStored.nickname
                emailTextView.text = userStored.email
                creditsTextView.text = getString(R.string.n_credits, userStored.credit)
                locationTextView.text = userStored.location
                skillsChipGroup.removeAllViews()
                if (userStored.skills.isEmpty()) {
                    val noSkillsTextView = TextView(requireContext())
                    noSkillsTextView.text = getString(R.string.no_skills)
                    skillsChipGroup.addView(noSkillsTextView)
                } else {
                    for (skill: String in userStored.skills) {
                        val skillChip = Chip(requireContext())
                        skillChip.text = skill
                        skillChip.setOnClickListener {
                            findNavController().navigate(ShowProfileFragmentDirections.actionShowProfileFragmentToTimeSlotListFragment(skill))
                        }
                        skillsChipGroup.addView(skillChip)
                    }
                }
            }
            else {
                Log.e("TIMEBANKING", "User does not exist in database!")
            }
        }
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        if (userId == Firebase.auth.currentUser!!.uid) {
            menu.clear()
            inflater.inflate(R.menu.edit_menu, menu)
        }
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.edit_menu_item -> {
                findNavController().navigate(ShowProfileFragmentDirections.actionShowProfileFragmentToEditProfileFragment())
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}